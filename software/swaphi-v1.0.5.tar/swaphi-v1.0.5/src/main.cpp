/*
 * main.cpp
 *
 *  Created on: Jun 19, 2013
 *      Author: yongchao
 */
#include "BuildIndex.h"
#include "Align.h"

/*program version*/
#define SWAPHI_VERSION "v1.0.5"

/*program usage*/
static void printUsage() {
	Utils::log(
			"SWAPhi (%s) is a parallel Smith-Waterman algorithm on Intel Xeon Phi coprocessors\n",
			SWAPHI_VERSION);
	Utils::log("Commands:\n");
	Utils::log(
			"\tindex          (build indices for the input subject sequences)\n");
	Utils::log("\talign          (align the query to the subject sequences\n");
}
int main(int argc, char* argv[]) {
	int index = 1;

	/*parse parameters*/
	if (argc < 2) {
		printUsage();
		return 1;
	}

	/*get the command*/
	if (!strcmp(argv[index], "index")) {
		BuildIndex(argc - 1, argv + 1);
	} else if (!strcmp(argv[index], "align")) {
		Align(argc - 1, argv + 1);
	} else {
		Utils::log("Unsupported command: %s\n", argv[index]);
		printUsage();
	}
	return 0;
}

