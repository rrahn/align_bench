/*
 * AlignCore.cpp
 *
 *  Created on: Jun 21, 2013
 *      Author: yongchao
 */

#include "AlignCore.h"

AlignCore::AlignCore(Align* align, int32_t micIndex) {
	_align = align;
	_gapOE = -align->getGapOE(); /*negative*/
	_gapExtend = -align->getGapExtend(); /*negative*/

	//Utils::log("_gapOE: %d _gapExtend: %d\n", _gapOE, _gapExtend);
	_matrix = align->getMatrix();
	_useQueryProfile = align->isUseQueryProfile();
	_micIndex = micIndex;

	/*get the number of threads on Xeon Phi*/
	_numMicThreads = align->getNumMicThreads();

	/*get the database data*/
	_aac = align->getAac(_micIndex);
	_aof = align->getAof(_micIndex);
	_ttl = align->getTtl();
	_tof = align->getTof();
}

__attribute__((target(mic))) void AlignCore::printVector(int32_t tid, const __m512i vec)
{
#ifdef __MIC__
	int32_t scores[16];

    /*store the alignment score*/
    _mm512_packstorelo_epi32(scores, vec);
    _mm512_packstorehi_epi32(scores + 16, vec);
	
	printf("tid %d: ", tid);
	for(int i = 0; i < 16; ++i){
		printf("%d ", scores[i]);
	}
	printf("\n");
#endif
}
