/*
 * AlignCoreIntra.cpp
 *
 *  Created on: Jun 28, 2013
 *      Author: yongchao
 */

#include "AlignCoreIntra.h"

AlignCoreIntra::AlignCoreIntra(Align* align, int32_t micIndex) :
		AlignCore(align, micIndex) {
	
	/*memory on the device*/
	_vecHEdata = NULL;
	_alignScores = align->getAlignScoreAddr(_micIndex);
}
AlignCoreIntra::~AlignCoreIntra() {
	if (_vecHEdata) {
		_mm_free(_vecHEdata);
	}
}
void AlignCoreIntra::initialize(QueryProfile* qprofile,
		uint32_t queryLength) {
	uint64_t vecHESize;

	/*set query profile*/
	_qprofile = qprofile->_data;
	_qprofileSize = qprofile->_width * qprofile->_height;
	_qprofileWidth = qprofile->_width;

	/*allocate host buffer*/
	_numQueryVectors = (queryLength + 15) >> 4;
	_vecHESize = _numQueryVectors * _numMicThreads * 3;
	_vecHEdata = (__m512i *) _mm_malloc(_vecHESize * sizeof(__m512i ), 64); /*dummy allocation*/
}

void AlignCoreIntra::finalize() {
	/*free host memory*/
	if (_vecHEdata) {
		_mm_free(_vecHEdata);
		_vecHEdata = NULL;
	}
}
void AlignCoreIntra::align(Sequence& query) {
 	uint32_t queryLength = query._length; /*get the query length*/

	/*prepare pointers for the offload*/
 	int8_t *qprofile = _qprofile;
	__m512i *vecHEdata = _vecHEdata;
  uint64_t first, firstAddrOff;
 	uint64_t numChunks;

#pragma offload target(mic:_micIndex) \
	in(qprofile: length(_qprofileSize) MIC_ALLOC) \
	nocopy(vecHEdata: length(_vecHESize) MIC_ALLOC) 
	{
     /*do nothing*/
	}

	double stime, etime;
	stime = Utils::getSysTime();
 while((numChunks = _align->getWorkloadPerBatch(first, firstAddrOff, _micIndex)) > 0){
    /*calculate relevant data*/
    uint64_t last = first + numChunks;
    uint64_t numBytesChunks = _aof[last] - _aof[first];
    int8_t* chunks = _aac + firstAddrOff; /*the starting address of the chunk data*/
    uint64_t *chunksOffs = _aof + first; /*the starting address of the offsets*/
   	int32_t *chunksOutput = _alignScores + first;	/*get the alignment score buffer*/

    Utils::log("micIndex: %d first: %ld numChunks %ld firstAddrOff: %ld numBytesChunks %ld\n", _micIndex, first, numChunks, firstAddrOff, numBytesChunks);

    /*perform alignment on the batch of chunks*/
#pragma offload target(mic:_micIndex) \
		in(chunks:length(numBytesChunks) MIC_ALLOC_FREE) \
		in(chunksOffs:length(numChunks + 1) MIC_ALLOC_FREE)  \
		nocopy(qprofile: MIC_REUSE) \
		nocopy(vecHEdata: length(_vecHESize) MIC_REUSE) \
		out(chunksOutput:length(numChunks) MIC_ALLOC_FREE)
		{
			smithWaterman(_numMicThreads, chunks, chunksOffs, numChunks, firstAddrOff, qprofile, _qprofileWidth, _numQueryVectors,
					vecHEdata, chunksOutput, _gapOE, _gapExtend);
		}
   }
   etime = Utils::getSysTime();
   Utils::log("Xeon Phi %d takes: %f seconds\n", _micIndex, etime - stime);

#pragma offload target(mic:_micIndex) \
	nocopy(qprofile: MIC_FREE) \
	nocopy(vecHEdata: MIC_FREE) 
	{
		/*do nothing*/
	}
}

__attribute__((target(mic))) void AlignCoreIntra::smithWaterman(const int32_t numMicThreads,
  const int8_t* __restrict__ chunks, const uint64_t* __restrict__ chunksOffs, const uint64_t numChunks,
  const uint64_t firstAddrOff, const int8_t* __restrict__ qprofile, const int32_t qprofileWidth, const int32_t numQueryVectors,
	 __m512i* __restrict__ vecHEdata, int32_t* __restrict__ chunksOutput, const int32_t gapOE, const int32_t gapExtend)
{
#ifdef __MIC__
  int32_t ichunk, tid, chunkLength, offset;
  register __m512i vecGapExtend, vecGapOE, vecZero, vecShift;

  /*set the number of threads*/
  omp_set_num_threads(numMicThreads);
  //printf("numthreads: %d numChunks: %ld\n", numMicThreads, numChunks);

  /*generate the gap extend penalty*/
  vecGapExtend = _mm512_set_epi32(gapExtend, gapExtend, gapExtend, gapExtend,
    gapExtend, gapExtend, gapExtend, gapExtend, gapExtend, gapExtend,
    gapExtend, gapExtend, gapExtend, gapExtend, gapExtend, gapExtend);

  /*generate the sum of gap open and extension penalties*/
  vecGapOE = _mm512_set_epi32(gapOE, gapOE, gapOE, gapOE, gapOE, gapOE,
    gapOE, gapOE, gapOE, gapOE, gapOE, gapOE, gapOE, gapOE, gapOE,
    gapOE);

	vecShift = _mm512_set_epi32(14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, 15);
  vecZero = _mm512_setzero_epi32();

#pragma omp parallel for private(ichunk, tid, chunkLength, offset) default(shared) schedule(guided, 1)
  for (ichunk = 0; ichunk < numChunks; ++ichunk) {

    /*get the thread index on the device*/
		tid = omp_get_thread_num();

    /*get the subject sequence length*/
		chunkLength = chunksOffs[ichunk + 1] - chunksOffs[ichunk];

    /*get the offset of the subject sequence length*/
		offset = chunksOffs[ichunk] - firstAddrOff;
	
		//printf("offset: %d chunkLength: %d numQueryVectors: %d\n", offset, chunkLength, numQueryVectors);

		/*run the kernel*/
		swKernel(qprofile, qprofileWidth, numQueryVectors, chunks + offset, chunkLength, vecHEdata + tid * numQueryVectors * 3,
					chunksOutput + ichunk, vecGapOE, vecGapExtend, vecZero, vecShift);
  }
#endif
}

__attribute__((target(mic)))
void AlignCoreIntra::swKernel(const int8_t * __restrict__ qprofile, const int32_t qprofileWidth, const int32_t numQueryVectors,
      const int8_t* __restrict__ chunk, const int32_t chunkLength, __m512i* __restrict__ vecHEdata,
      int32_t* alnScores, const __m512i vecGapOE, const __m512i vecGapExtend, const __m512i vecZero,
			const __m512i vecShift)
{

		int32_t scores[16];	
		register int32_t maxScore = 0;
		register __m512i vecS, vecH, vecE, vecMax;
		register __m512i zero, vecF, vecTmp;
		const __m128i* __restrict__ vecQprofile;
		register __mmask16 mask, maskShift;
		register int32_t i, j;
		__m512i* __restrict__ vecPtr;
		__m512i* __restrict__ vecHload = vecHEdata;
		__m512i* __restrict__ vecHstore = vecHload + numQueryVectors;
		__m512i* __restrict__ vecEdata = vecHstore + numQueryVectors;

#ifdef __MIC__
	//printf("numQueryVectors: %d qprofileWidth %d chunkLength %d\n", numQueryVectors, qprofileWidth, chunkLength);
	/*initialize the H and E vectors with zero*/
	memset(vecHstore, 0, numQueryVectors * sizeof(vecHstore[0]));
	memset(vecEdata, 0, numQueryVectors * sizeof(vecEdata[0]));

	/*core loop*/
	vecMax = vecZero;
	maskShift = _mm512_int2mask(0x0fffe);
	for (i = 0; i < chunkLength; ++i) { /*target on the row*/

		/*get a row from the query profile*/
		vecQprofile = (const __m128i*) (qprofile + chunk[i] * qprofileWidth) ;

		/*zero F*/
		vecF = vecZero;

		/*load the next H value*/
		vecH = _mm512_load_epi32(vecHstore + numQueryVectors - 1);

		/*left shift by one element*/
		vecH = _mm512_mask_permutevar_epi32(vecZero, maskShift, vecShift, vecH);

		/*swap the pointers*/
		vecPtr = vecHstore;
		vecHstore = vecHload;
		vecHload = vecPtr;

		/*the inner core loop*/
		for (j = 0; j < numQueryVectors; ++j) { /*query on the column*/

			/*load E values*/
			vecE = _mm512_load_epi32(vecEdata + j);

			/*calculate the H avlue*/
			vecS = _mm512_extload_epi32(vecQprofile++, _MM_UPCONV_EPI32_SINT8, _MM_BROADCAST32_NONE, 0);
			vecH = _mm512_max_epi32(vecZero, _mm512_add_epi32(vecH, vecS));	/*saturation operation*/

			/*calculate the maximum alignment score*/
			vecMax = _mm512_max_epi32(vecMax, vecH);

			/*get max from E anf F*/
			vecH = _mm512_max_epi32(vecH, vecE);
			vecH = _mm512_max_epi32(vecH, vecF);

			/*save H value*/
			_mm512_store_epi32(vecHstore + j, vecH);

			/*update E value*/
			vecH = _mm512_max_epi32(vecZero, _mm512_add_epi32(vecH, vecGapOE));	/*saturation operation*/
			vecE = _mm512_add_epi32(vecE, vecGapExtend);
			vecE = _mm512_max_epi32(vecE, vecH);

			/*update F value*/
			vecF = _mm512_add_epi32(vecF, vecGapExtend);
			vecF = _mm512_max_epi32(vecF, vecH);

			/*save E value*/
			_mm512_store_epi32(vecEdata + j, vecE);

			/*load the next H value*/
			vecH = _mm512_load_epi32(vecHload + j);
		}

		/*reset pointers to the start of the saved data*/
		j = 0;
		vecH = _mm512_load_epi32(vecHstore + j);

		/*left shift F by one element*/
		vecF = _mm512_mask_permutevar_epi32(vecZero, maskShift, vecShift, vecF);

		/*test the values*/
		vecTmp = _mm512_max_epi32(vecZero, _mm512_add_epi32(vecH, vecGapOE)); /*saturation operation*/
		mask = _mm512_cmpgt_epi32_mask(vecF, vecTmp);
		while(mask != 0){

			vecE = _mm512_load_epi32(vecEdata + j);
			vecH = _mm512_max_epi32(vecH, vecF);

			/*save the H values*/
			_mm512_store_epi32(vecHstore + j, vecH);

			/*update E*/
			vecH = _mm512_max_epi32(vecZero, _mm512_add_epi32(vecH, vecGapOE));
			vecE = _mm512_max_epi32(vecE, vecH);
			_mm512_store_epi32(vecEdata + j, vecE);

			/*update F value*/
			vecF = _mm512_add_epi32(vecF, vecGapExtend);

			if(++j >= numQueryVectors){
				j = 0;
				/*left shift F by one element*/
				vecF = _mm512_mask_permutevar_epi32(vecZero, maskShift, vecShift, vecF);
			}
			vecH = _mm512_load_epi32(vecHstore + j);

			/*re-test the values*/
			vecTmp = _mm512_max_epi32(vecZero, _mm512_add_epi32(vecH, vecGapOE));
			mask = _mm512_cmpgt_epi32_mask(vecF, vecTmp);
		}
	}
	/*store the alignment score*/
	_mm512_packstorelo_epi32(scores, vecMax);
	_mm512_packstorehi_epi32(scores + 16, vecMax);

	/*find the maximum alignment scores*/
	maxScore = scores[0];
	for(int32_t i = 15; i > 0; --i){
		if(maxScore < scores[i]){
			maxScore = scores[i];
		}
	}
			
	/*save the alignment score*/
	*alnScores = maxScore;;
#endif
}

