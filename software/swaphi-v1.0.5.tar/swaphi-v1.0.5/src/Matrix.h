/*
 * Matrix.h
 *
 *  Created on: Jun 20, 2013
 *      Author: yongchao
 */

#ifndef MATRIX_H_
#define MATRIX_H_
#include "Macros.h"

class Matrix {
public:
	static void getMatrix(const char* name, int8_t* matrix);

private:
	static const int8_t blosum45[32][32];
	static const int8_t blosum50[32][32];
	static const int8_t blosum62[32][32];
	static const int8_t blosum80[32][32];
};

#endif /* MATRIX_H_ */
