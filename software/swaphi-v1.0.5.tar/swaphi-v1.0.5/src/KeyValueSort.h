/*
 * KeyValueSort.h
 *
 *  Created on: Jul 16, 2013
 *      Author: yongchao
 */

#ifndef KEYVALUESORT_H_
#define KEYVALUESORT_H_
#include "Macros.h"

#define BWTINC_INSERT_SORT_NUM_ITEM 7
#define EQUAL_KEY_THRESHOLD	 4	// Partition for equal key if data array size / the number of data with equal value with pivot < EQUAL_KEY_THRESHOLD


template <class TypeKey, class TypeValue>
class KeyValueSort
{
public:
	static void keyValueSort(TypeKey *keys, TypeValue* values,
			const int64_t numItem);

private:
	static inline int64_t _average(int64_t a, int64_t b)
	{
		return (a + b) / 2;
	}
};

template <class TypeKey, class TypeValue>
void KeyValueSort<TypeKey, TypeValue>::keyValueSort(TypeKey *keys, TypeValue* values,
		const int64_t numItem) {

	int64_t lowIndex, highIndex, midIndex;
	int64_t lowPartitionIndex, highPartitionIndex;
	int64_t lowStack[64], highStack[64];
	int64_t stackDepth;
	int64_t i, j;
	TypeValue tempSeq;
	TypeKey tempKey;
	int64_t numberOfEqualKey;

	if (numItem < 2) {
		return;
	}

	stackDepth = 0;
	lowIndex = 0;
	highIndex = numItem - 1;

	while (1) {
		while (1) {
			// Sort small array of data
			if (highIndex - lowIndex < BWTINC_INSERT_SORT_NUM_ITEM) { // Insertion sort on smallest arrays
				for (i = lowIndex + 1; i <= highIndex; i++) {
					tempSeq = values[i];
					tempKey = keys[i];
					for (j = i; j > lowIndex && keys[j - 1] > tempKey; j--) {
						values[j] = values[j - 1];
						keys[j] = keys[j - 1];
					}
					if (j != i) {
						values[j] = tempSeq;
						keys[j] = tempKey;
					}
				}
				break;
			}

			// Choose pivot as median of the lowest, middle, and highest data; sort the three data
			midIndex = _average(lowIndex, highIndex);
			if (keys[lowIndex] > keys[midIndex]) {
				tempSeq = values[lowIndex];
				tempKey = keys[lowIndex];
				values[lowIndex] = values[midIndex];
				keys[lowIndex] = keys[midIndex];
				values[midIndex] = tempSeq;
				keys[midIndex] = tempKey;
			}
			if (keys[lowIndex] > keys[highIndex]) {
				tempSeq = values[lowIndex];
				tempKey = keys[lowIndex];
				values[lowIndex] = values[highIndex];
				keys[lowIndex] = keys[highIndex];
				values[highIndex] = tempSeq;
				keys[highIndex] = tempKey;
			}
			if (keys[midIndex] > keys[highIndex]) {
				tempSeq = values[midIndex];
				tempKey = keys[midIndex];
				values[midIndex] = values[highIndex];
				keys[midIndex] = keys[highIndex];
				values[highIndex] = tempSeq;
				keys[highIndex] = tempKey;
			}

			// Partition data

			numberOfEqualKey = 0;

			lowPartitionIndex = lowIndex + 1;
			highPartitionIndex = highIndex - 1;

			for (;;) {
				while (lowPartitionIndex <= highPartitionIndex
						&& keys[lowPartitionIndex] <= keys[midIndex]) {
					numberOfEqualKey += (keys[lowPartitionIndex]
							== keys[midIndex]);
					lowPartitionIndex++;
				}
				while (lowPartitionIndex < highPartitionIndex) {
					if (keys[midIndex] >= keys[highPartitionIndex]) {
						numberOfEqualKey += (keys[midIndex]
								== keys[highPartitionIndex]);
						break;
					}
					highPartitionIndex--;
				}
				if (lowPartitionIndex >= highPartitionIndex) {
					break;
				}
				tempSeq = values[lowPartitionIndex];
				tempKey = keys[lowPartitionIndex];
				values[lowPartitionIndex] = values[highPartitionIndex];
				keys[lowPartitionIndex] = keys[highPartitionIndex];
				values[highPartitionIndex] = tempSeq;
				keys[highPartitionIndex] = tempKey;
				if (highPartitionIndex == midIndex) {
					// partition keys has been moved
					midIndex = lowPartitionIndex;
				}
				lowPartitionIndex++;
				highPartitionIndex--;
			}

			// Adjust the partition index
			highPartitionIndex = lowPartitionIndex;
			lowPartitionIndex--;

			// move the partition key to end of low partition
			tempSeq = values[midIndex];
			tempKey = keys[midIndex];
			values[midIndex] = values[lowPartitionIndex];
			keys[midIndex] = keys[lowPartitionIndex];
			values[lowPartitionIndex] = tempSeq;
			keys[lowPartitionIndex] = tempKey;

			if (highIndex - lowIndex + BWTINC_INSERT_SORT_NUM_ITEM
					<= EQUAL_KEY_THRESHOLD * numberOfEqualKey) {

				// Many keys = partition key; separate the equal key data from the lower partition

				midIndex = lowIndex;

				for (;;) {
					while (midIndex < lowPartitionIndex
							&& keys[midIndex] < keys[lowPartitionIndex]) {
						midIndex++;
					}
					while (midIndex < lowPartitionIndex
							&& keys[lowPartitionIndex]
									== keys[lowPartitionIndex - 1]) {
						lowPartitionIndex--;
					}
					if (midIndex >= lowPartitionIndex) {
						break;
					}
					tempSeq = values[midIndex];
					tempKey = keys[midIndex];
					values[midIndex] = values[lowPartitionIndex - 1];
					keys[midIndex] = keys[lowPartitionIndex - 1];
					values[lowPartitionIndex - 1] = tempSeq;
					keys[lowPartitionIndex - 1] = tempKey;
					midIndex++;
					lowPartitionIndex--;
				}

			}

			if (lowPartitionIndex - lowIndex > highIndex - highPartitionIndex) {
				// put the larger partition to stack
				lowStack[stackDepth] = lowIndex;
				highStack[stackDepth] = lowPartitionIndex - 1;
				stackDepth++;
				// sort the smaller partition first
				lowIndex = highPartitionIndex;
			} else {
				// put the larger partition to stack
				lowStack[stackDepth] = highPartitionIndex;
				highStack[stackDepth] = highIndex;
				stackDepth++;
				// sort the smaller partition first
				if (lowPartitionIndex > lowIndex) {
					highIndex = lowPartitionIndex - 1;
				} else {
					// all keys in the partition equals to the partition key
					break;
				}
			}
			continue;
		}

		// Pop a range from stack
		if (stackDepth > 0) {
			stackDepth--;
			lowIndex = lowStack[stackDepth];
			highIndex = highStack[stackDepth];
			continue;
		} else
			return;
	}
}

#endif /* KEYVALUESORT_H_ */
