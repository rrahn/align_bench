/*
 * Align.h
 *
 *  Created on: Jun 19, 2013
 *      Author: yongchao
 */

#ifndef ALIGN_H_
#define ALIGN_H_

#include "Macros.h"
#include "Utils.h"
#include "Sequence.h"

class Align {
public:
	Align(int argc, char* argv[]);
	~Align();

	/*run the alignment*/
	void run();

	inline uint32_t getNumMicThreads() {
		return _numMicThreads;
	}
	inline int8_t* getAac(int32_t which) {
		return _aacs[which];
	}
	inline uint64_t* getAof(int32_t which) {
		return _aofs[which];
	}
	inline int8_t* getTtl() {
		return _ttl;
	}
	inline uint64_t* getTof() {
		return _tof;
	}

	inline int32_t getGapExtend() {
		return _gapExtend;
	}
	inline int32_t getGapOE() {
		return _gapOpen + _gapExtend;
	}
	inline void lock()
	{
		pthread_mutex_lock(&_mutex);
	}
	inline void unlock()
	{
		pthread_mutex_unlock(&_mutex);
	}
	inline int32_t* getAlignScoreAddr(int micIndex)
	{
		return _alignScoresAddrs[micIndex];
	}
	inline int8_t* getMatrix()
	{
		return _matrix;
	}
	inline int32_t isUseQueryProfile()
	{
		return _useQueryProfile;
	}

	uint64_t getWorkloadPerBatch(uint64_t& first, uint64_t &firstAddrOff, int32_t micIndex);
private:
	/*parallelization*/
	int32_t _compMode;

	/*threads*/
	uint32_t _numMicThreads;

	/*number of MICs used*/
	int32_t _numXeonPhis;

	/*scoring scheme*/
	string _matrixName;
	int8_t* _matrix;
	int32_t _gapOpen;
	int32_t _gapExtend;
	int32_t _gapOE;

	/*database and query*/
	string _dbFilePrefix;
	string _queryFileName;
	int32_t *_alignScores;
	int64_t *_alignIndices;
	vector<int32_t*> _alignScoresAddrs;
	int32_t _loadEntirely;
	int32_t _useQueryProfile;
	pthread_mutex_t _mutex;

	vector<int8_t*> _aacs; /*amino acids*/
	vector<uint64_t> _aacLengths;
	vector<uint64_t> _numSeqsPerFile;

	vector<uint64_t*> _aofs; /*amino acid displacement*/
	vector<uint64_t> _aofLengths;

	int8_t* _ttl; /*titles*/
	uint64_t _ttlLength;
	uint64_t *_tof, *_tofAddr; /*title displacement*/
	uint64_t _tofLength;

	uint64_t _numSeqs; /*number of sequences*/
	uint64_t _numChunks; /*number of chunks*/
	uint64_t _maxLength;
	uint64_t _minLength;
	uint64_t _totalNumChars;
	uint64_t _totalNumBytes;
	uint64_t _numTopHits;

	/*get the workload per batch*/
	uint64_t _maxBytesPerFetch;
	vector< list<WorkloadEntry> > _workloads;

	void _setDefaults(); /*set default parameters*/
	void _waitForBarrier();
	void _allocAlignScores();
	void _initAlignScoreIndices(int64_t* alignScoresIndices);
	void _calcWorkloadPerBatch();

	/*database memory mapping*/
	void _memMapDatabase(const string& dbPrefix);
	void _memUnmapDatabase();

	/*print out parameters*/
	void _printUsage();

	/*report alignment scores*/
	void _reportAlignScores(Sequence& _query, int32_t* alignScores, int64_t* alignIndices);

	/*thread functions*/
	static void* _threadFunc(void*);
};

#endif /* ALIGN_H_ */
