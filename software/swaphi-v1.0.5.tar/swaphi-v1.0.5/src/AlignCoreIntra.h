/*
 * AlignCoreIntra.h
 *
 *  Created on: Jun 28, 2013
 *      Author: yongchao
 */

#ifndef ALIGNCOREINTRA_H_
#define ALIGNCOREINTRA_H_
#include "AlignCore.h"

class AlignCoreIntra: public AlignCore {
public:
	AlignCoreIntra(Align* align, int dev);
	~AlignCoreIntra();

	/*alignment*/
	void align(Sequence& query);

	/*allocate intermediate buffer*/
	void initialize(QueryProfile* qprofile, uint32_t queryLength);
	void finalize();

private:
	__m512i * _vecHEdata;
	int32_t _vecHESize;
	int32_t _numQueryVectors;
	int8_t * _chunks;
	uint64_t *_chunksOffs;
	int32_t* _alignScores;

	__attribute__((target(mic))) void smithWaterman(const int32_t numMicThreads,
  	const int8_t* __restrict__ chunks, const uint64_t* __restrict__ chunksOffs, const uint64_t numChunks,
  	const uint64_t firstAddrOff, const int8_t* __restrict__ qprofile, const int32_t qprofileWidth, const int32_t numQueryVectors,
  	__m512i* __restrict__ vecHEdata, int32_t* __restrict__ chunksOutput, const int32_t gapOE, const int32_t gapExtend);


	/*Smith-Waterman kernel function*/
	__attribute__((target(mic)))
	void swKernel(const int8_t* __restrict__ qprofile, const int32_t qprofileWidth, const int32_t numQueryVectors,
      const int8_t* __restrict__ chunk, const int32_t chunkLength, __m512i* __restrict__ vecHEdata,
      int32_t* alnScores, const __m512i vecGapOE, const __m512i vecGapExtend, const __m512i vecZero,
      const __m512i vecShift);
};

#endif /* ALIGNCOREINTRA_H_ */
