/*
 * BuildIndex.cpp
 *
 *  Created on: Jun 19, 2013
 *      Author: yongchao
 */

#include "BuildIndex.h"
#include "SeqFileParser.h"

#if 0
/*redefine macros*/
#undef SEQ_LENGTH_ALIGN_SHIFT
#undef SEQ_LENGTH_ALIGN
#undef SEQ_LENGTH_ALIGN_MASK

#define SEQ_LENGTH_ALIGN_SHIFT      3
#define SEQ_LENGTH_ALIGN            (1 << SEQ_LENGTH_ALIGN_SHIFT)
#define SEQ_LENGTH_ALIGN_MASK       ((1 << SEQ_LENGTH_ALIGN_SHIFT) - 1)
#endif

void BuildIndex::_printUsage() {
	Utils::log("Usage: swaphi index [options]\n");
	Utils::log("\t-x <int> (number of Intel Xeon Phi coprocessors [REQUIRED])\n");
	Utils::log("\t-i <str> (input sequence file in FASTA/FASTQ format [REQUIRED])\n");
	Utils::log(
			"\t-o <str> (prefix of output index files, default = INPUT file name [OPTIONAL])\n");
	Utils::log("\t-m <int> (minimum sequence length, default = %u [OPTIONAL])\n", _minAllowableLength);
	Utils::log("\t-M <int> (maximum sequence length, default = %u [OPTIONAL])\n", _maxAllowableLength);
	Utils::log("\t-n <int> (the first number of sequences in the input, default = %ld [OPTIONAL])\n", (int64_t)_maxNumSeqs);
}
BuildIndex::BuildIndex(int argc, char* argv[]) {
	int c;
	int32_t val;
	uint32_t length;
	SeqFileParser* parser;
	double stime, etime;
	
	/*set the maximum allowable sequence length*/
	_minAllowableLength = 0;
	_maxAllowableLength = (uint32_t)-1;
	_numXeonPhis = 0;
	_maxNumSeqs = (uint64_t)-1;

	/*parse parameters*/
	if (argc < 3) {
		_printUsage();
		exit(0);
	}
	while ((c = getopt(argc, argv, "x:i:o:m:M:n:")) >= 0) {
		switch (c) {
		case 'x':
			val = atoi(optarg);
			if(val < 1){
				Utils::exit("Invalid number of Intel Xeon Phis: %d\n", val);
			}
			_numXeonPhis = val;
			break;
		case 'i':
			_inputFile = optarg;
			break;
		case 'o':
			_outPrefix = optarg;
			break;
		case 'm':
			_minAllowableLength = atoi(optarg);
			if(_minAllowableLength < 0){
				_minAllowableLength = 0;
			}
			break;
		case 'M':
			_maxAllowableLength = atoi(optarg);
			break;
		case 'n':
			val = atoi(optarg);
			if(val <= 0){
				val = -1;
			}
			_maxNumSeqs = (uint64_t)val;
			break;
		default:
			Utils::exit("Unsupported option: %s\n", optarg);
			break;
		}
	}
	if(_numXeonPhis == 0){
		Utils::exit("MUST specify the number of Intel Xeon Phi coprocessors for the sequence indexing\n");
	}
	if (_inputFile.length() == 0) {
		Utils::exit("MUST give the input sequence file\n");
	}
	if (_outPrefix.length() == 0) {
		_outPrefix = _inputFile;
	}
	/*get the system time*/
	stime = Utils::getSysTime();

	/*get the number of sequences*/
	Utils::log("Counting the number of sequences\n");
	_numSeqs = _getNumSeqs(_inputFile.c_str());
	if (_numSeqs == 0) {
		Utils::exit("Empty database file and will exit...\n");
	}
	Utils::log("Having %ld qualified sequences\n", _numSeqs);
	_sequences = new Sequence*[_numSeqs];
	if (!_sequences) {
		Utils::exit("Memory allocation failed at line %d in file %s\n",
				__LINE__, __FILE__);
	}
	Utils::log("Allocate space for each sequence\n");
	/*allocate memory for each sequence*/
	for (uint64_t i = 0; i < _numSeqs; ++i) {
		_sequences[i] = new Sequence();
	}

	/*read all sequences*/
	Utils::log("Read into memory all sequences\n");
	parser = new SeqFileParser(_inputFile.c_str());
	if (!parser) {
		Utils::exit("Failed to open the file: %s\n", _inputFile.c_str());
	}
	_numSeqs = 0;
	_totalNumChars = 0;
	_maxLength = 0;
	_minLength = (uint32_t) -1;
	while (parser->getSeq(*(_sequences[_numSeqs]))) {
		/*calculate the minimum and maximum lengths*/
		length = _sequences[_numSeqs]->_length;

		if(_qualified(length)){
			_maxLength = max(_maxLength, length);
			_minLength = min(_minLength, length);
			/*increase the number of sequences*/
			++_numSeqs;
			/*increase the number of characters*/
			_totalNumChars += length;
		}else{
			_sequences[_numSeqs]->clear();
		}
		if(_numSeqs >= _maxNumSeqs){
			break;
		}
	}
	/*release the file parser*/
	delete parser;

	/*sort all sequences by length*/
	Utils::log("Sort all sequences in the descendant order of length\n");
	qsort(_sequences, _numSeqs, sizeof(*_sequences), _comp);

	Utils::log("Save the sequence titles\n");
	/*get the sequence name index*/
	_buildSeqNameIndex();

	/*pack the sorted sequences*/
	Utils::log("Save sequences for inter-task model\n");
	_pacSeqsVL16();

	/*pack the sorted sequences*/
	Utils::log("Save sequences for intra-task model\n");
	_plainSeqs();

	etime = Utils::getSysTime();
	Utils::log("Taken %f seconds to build the index\n", etime - stime);
}
BuildIndex::~BuildIndex() {

	/*release memory*/
	for (uint64_t i = 0; i < _numSeqs; ++i) {
		if (_sequences[i]) {
			delete _sequences[i];
		}
	}
	delete[] _sequences;
}
uint64_t BuildIndex::_getNumSeqs(const char* fileName) {
	uint64_t numSeqs = 0;
	Sequence seq;

	/*open the database file*/
	SeqFileParser* parser = new SeqFileParser(fileName);
	if (!parser) {
		Utils::exit("Failed to open the file: %s\n", fileName);
	}

	/*read the file*/
	while ((parser->getSeq(seq))) {
		if(_qualified(seq._length)){
			++numSeqs;
		}
		seq.clear();
		if(numSeqs >= _maxNumSeqs){
			break;
		}
	}

	/*release parser*/
	delete parser;

	return numSeqs;
}
void BuildIndex::_buildSeqNameIndex() {
	char nameBuffer[1024];
	uint64_t titleDisp;
	string titleFileName;
	string titleDispFileName;
	FILE *titleFile, *titleDispFile;

	sprintf(nameBuffer, ".np%d.ttl", _numXeonPhis);
	titleFileName = _outPrefix + nameBuffer; /*title file name*/
	sprintf(nameBuffer, ".np%d.tof", _numXeonPhis);
	titleDispFileName = _outPrefix + nameBuffer; /*title  displacement file*/

	/*open the output files*/
	titleFile = fopen(titleFileName.c_str(), "wb");
	if (!titleFile) {
		Utils::exit("Failed to open file: %s\n", titleFileName.c_str());
	}
	titleDispFile = fopen(titleDispFileName.c_str(), "wb");
	if (!titleDispFile) {
		Utils::exit("Failed to open file: %s\n", titleDispFileName.c_str());
	}

	/*write the number of sequences to the title displacement file*/
	titleDisp = _numSeqs;
	if (fwrite(&titleDisp, sizeof(titleDisp), 1, titleDispFile) != 1) {
		Utils::exit(
				"The number of sequences writing failed at line %d in file %s\n",
				__LINE__, __FILE__);
	}

	/*write the minimum sequence length to the title displace file*/
	titleDisp = _minLength;
	if (fwrite(&titleDisp, sizeof(titleDisp), 1, titleDispFile) != 1) {
		Utils::exit(
				"The number of sequences writing failed at line %d in file %s\n",
				__LINE__, __FILE__);
	}

	/*write the maximumsequence length to the title displace file*/
	titleDisp = _maxLength;
	if (fwrite(&titleDisp, sizeof(titleDisp), 1, titleDispFile) != 1) {
		Utils::exit(
				"The number of sequences writing failed at line %d in file %s\n",
				__LINE__, __FILE__);
	}
	/*write the total number of characters to the title displace file*/
	titleDisp = _totalNumChars;
	if (fwrite(&titleDisp, sizeof(titleDisp), 1, titleDispFile) != 1) {
		Utils::exit(
				"The number of sequences writing failed at line %d in file %s\n",
				__LINE__, __FILE__);
	}

	/*starting packing the sequences*/
	titleDisp = 0;
	for (uint64_t i = 0; i < _numSeqs; ++i) {
		char* name = _sequences[i]->_name;
		/*write sequence name*/
		uint32_t length = strlen(name) + 1; /*write the null terminate symbol together*/

		/*write the name*/
		if (fwrite(name, sizeof(name[0]), length, titleFile) != length) {
			Utils::exit("Sequence name writing failed at line %d in file %s\n",
					__LINE__, __FILE__);
		}

		/*write the displacement*/
		if (fwrite(&titleDisp, sizeof(titleDisp), 1, titleDispFile) != 1) {
			Utils::exit(
					"Sequence name displacement writing failed at line %d in file %s\n",
					__LINE__, __FILE__);
		}
		/*increase the displacement*/
		titleDisp += length;
	}
	/*write the displacement*/
	if(fwrite(&titleDisp, sizeof(titleDisp), 1, titleDispFile) != 1){
		Utils::exit(
                    "Sequence name displacement writing failed at line %d in file %s\n",
                    __LINE__, __FILE__);
	}

	/*close all files*/
	fclose(titleFile);
	fclose(titleDispFile);
}
uint64_t BuildIndex::_pacSeqsVL16() {
	int8_t* buffer;
	uint64_t numSeqs2;
	vector<int8_t> space;
	uint32_t lengths[16];
	uint32_t fullLength;
	Sequence* seqs[16]; /*sequence pointers*/

	/*generate the output file name*/
	vector<string> aacFileNames (_numXeonPhis, "");
	vector<string> dispFileNames (_numXeonPhis, "");

	char nameBuffer[1024];
	for(int32_t i = 0; i < _numXeonPhis; ++i){
		sprintf(nameBuffer, ".np%d.16.%d.aac", _numXeonPhis, i);
		aacFileNames[i] = _outPrefix + nameBuffer;

		sprintf(nameBuffer, ".np%d.16.%d.aof", _numXeonPhis, i);
		dispFileNames[i] = _outPrefix + nameBuffer;
	}

	/*open the output files*/
	vector<FILE*> aacFiles (_numXeonPhis, NULL);
	vector<FILE*> dispFiles (_numXeonPhis, NULL);;

	for(int32_t i = 0; i < _numXeonPhis; ++i){
		aacFiles[i] = fopen(aacFileNames[i].c_str(), "wb");
		if (!aacFiles[i]) {
			Utils::exit("Failed to open file: %s\n", aacFileNames[i].c_str());
		}
		dispFiles[i] = fopen(dispFileNames[i].c_str(), "wb");
		if (!dispFiles[i]) {
			Utils::exit("Failed to open file: %s\n", dispFileNames[i].c_str());
		}
	}

	/*starting packing the sequences*/
	int32_t whichFile = 0;
	vector<uint64_t> disps(_numXeonPhis, 0);
	vector<uint64_t> numSeqsPerFile (_numXeonPhis, 0);

	numSeqs2 = (_numSeqs >> 4) << 4; /*aligned to 16*/
	for (uint64_t i = 0; i < numSeqs2; i += 16) {
		/*get the sequence information*/
		fullLength = 0;
		for (uint32_t k = 0; k < 16; ++k) {
			seqs[k] = _sequences[i + k];
			lengths[k] = seqs[k]->_length;
			fullLength = max(lengths[k], fullLength);
		}
		fullLength = ((fullLength + SEQ_LENGTH_ALIGN_MASK) >> SEQ_LENGTH_ALIGN_SHIFT) << SEQ_LENGTH_ALIGN_SHIFT;
		space.resize(16 * fullLength);

		/*copy the sequence*/
		buffer = &space[0];
		for (uint32_t j = 0; j < fullLength; ++j) {
			for (uint32_t k = 0; k < 16; ++k) {
				*buffer++ =
						j < lengths[k] ? seqs[k]->_bases[j] : DUMMY_AMINO_ACID;
			}
		}

		/*write amino acid displacement*/
		if (fwrite(&disps[whichFile], sizeof(uint64_t), 1, dispFiles[whichFile]) != 1) {
			Utils::exit("Displacement writing failed at line %d in file %s\n",
					__LINE__, __FILE__);
		}
		/*increase the displacement*/
		disps[whichFile] += fullLength * 16;
		numSeqsPerFile[whichFile] += 16;

		/*write amino acids*/
		if (fwrite(&space[0], sizeof(space[0]), 16 * fullLength, aacFiles[whichFile])
				!= 16 * fullLength) {
			Utils::exit("Amino acids writing failed at line %d in file %s\n",
					__LINE__, __FILE__);
		}

		/*move to the next file*/
		if(++whichFile == _numXeonPhis){
			whichFile = 0;
		}
	}
	/*check if _numSeqs is multiples of 16*/
	if (_numSeqs & 0x0F) {
		/*pack the remaining sequences*/
		fullLength = 0;
		for (uint32_t k = 0; k < 16; ++k) {
			if (k + numSeqs2 < _numSeqs) {
				seqs[k] = _sequences[numSeqs2 + k];
				lengths[k] = seqs[k]->_length;
				fullLength = max(fullLength, lengths[k]);
			} else {
				seqs[k] = NULL;
				lengths[k] = 0;
			}
		}

		/*calculate the memory size*/
		fullLength = ((fullLength + SEQ_LENGTH_ALIGN_MASK) >> SEQ_LENGTH_ALIGN_SHIFT) << SEQ_LENGTH_ALIGN_SHIFT;
		space.resize(16 * fullLength);

		/*copy the sequence*/
		buffer = &space[0];
		for (uint32_t j = 0; j < fullLength; ++j) {
			for (uint32_t k = 0; k < 16; ++k) {
				*buffer++ =
						j < lengths[k] ? seqs[k]->_bases[j] : DUMMY_AMINO_ACID;
			}
		}
#if 0
		buffer = &space[0];
		for(uint32_t j = 0; j < fullLength; ++j){
			for(uint32_t k = 0; k < 16; ++k){
				Utils::log("%d ", *buffer++);
			}
			Utils::log("\n");
		}
#endif
		/*write amino acid displacement*/
		if (fwrite(&disps[whichFile], sizeof(uint64_t), 1, dispFiles[whichFile]) != 1) {
			Utils::exit("Displacement writing failed at line %d in file %s\n",
					__LINE__, __FILE__);
		}
		/*increase the displacement*/
		disps[whichFile] += fullLength * 16;
		numSeqsPerFile[whichFile] += _numSeqs & 0x0F;

		/*write amino acids*/
		if (fwrite(&space[0], sizeof(space[0]), 16 * fullLength, aacFiles[whichFile])
				!= 16 * fullLength) {
			Utils::exit("Amino acids writing failed at line %d in file %s\n",
					__LINE__, __FILE__);
		}
	}

	/*close all files*/
	for(int32_t i = 0; i < _numXeonPhis; ++i){
		/*write amino acid displacement*/
		if (fwrite(&disps[i], sizeof(uint64_t), 1, dispFiles[i]) != 1) {
			Utils::exit("Displacement writing failed at line %d in file %s\n",
				__LINE__, __FILE__);
		}

		/*write the number of sequences*/
    if (fwrite(&numSeqsPerFile[i], sizeof(uint64_t), 1, dispFiles[i]) != 1) {
      Utils::exit("Number of sequences per file writing failed at line %d in file %s\n",
        __LINE__, __FILE__);
    }

		fclose(aacFiles[i]);
		fclose(dispFiles[i]);
	}

	/*return the number of chunks*/
	return (_numSeqs + 15) >> 4;
}

uint64_t BuildIndex::_plainSeqs() {
	vector<int8_t> space;
	uint32_t length;
	Sequence* seqs[16]; /*sequence pointers*/

  /*generate the output file name*/
  vector<string> aacFileNames (_numXeonPhis, "");
  vector<string> dispFileNames (_numXeonPhis, "");

  char nameBuffer[1024];
  for(int32_t i = 0; i < _numXeonPhis; ++i){
    sprintf(nameBuffer, ".np%d.1.%d.aac", _numXeonPhis, i);
    aacFileNames[i] = _outPrefix + nameBuffer;

    sprintf(nameBuffer, ".np%d.1.%d.aof", _numXeonPhis, i);
    dispFileNames[i] = _outPrefix + nameBuffer;
  }

  /*open the output files*/
  vector<FILE*> aacFiles (_numXeonPhis, NULL);
  vector<FILE*> dispFiles (_numXeonPhis, NULL);;

  for(int32_t i = 0; i < _numXeonPhis; ++i){
    aacFiles[i] = fopen(aacFileNames[i].c_str(), "wb");
    if (!aacFiles[i]) {
      Utils::exit("Failed to open file: %s\n", aacFileNames[i].c_str());
    }
    dispFiles[i] = fopen(dispFileNames[i].c_str(), "wb");
    if (!dispFiles[i]) {
      Utils::exit("Failed to open file: %s\n", dispFileNames[i].c_str());
    }
  }

	/*starting packing the sequences*/
  int32_t whichFile = 0;
  vector<uint64_t> disps(_numXeonPhis, 0);
	vector<uint64_t> numSeqsPerFile( _numXeonPhis, 0);

	for (uint64_t i = 0; i < _numSeqs; ++i) {

		/*get the sequence length*/
		length = _sequences[i]->_length;

		/*write amino acid displacement*/
		if (fwrite(&disps[whichFile], sizeof(uint64_t), 1, dispFiles[whichFile]) != 1) {
			Utils::exit("Displacement writing failed at line %d in file %s\n",
					__LINE__, __FILE__);
		}
		/*increase the displacement*/
		disps[whichFile] += length;
		numSeqsPerFile[whichFile] += 1;

		/*write amino acids*/
		if (fwrite(_sequences[i]->_bases, sizeof(uint8_t), length, aacFiles[whichFile])
				!= length) {
			Utils::exit("Amino acids writing failed at line %d in file %s\n",
					__LINE__, __FILE__);
		}

		/*move to the next file*/
		if(++whichFile == _numXeonPhis){
			whichFile = 0;
		}
	}
	/*close all files*/
	for(int32_t i = 0; i < _numXeonPhis; ++i){
 	 	/*write amino acid displacement*/
  	if (fwrite(&disps[i], sizeof(uint64_t), 1, dispFiles[i]) != 1) {
    	Utils::exit("Displacement writing failed at line %d in file %s\n",
        __LINE__, __FILE__);
  	}

    /*write the number of sequences*/
    if (fwrite(&numSeqsPerFile[i], sizeof(uint64_t), 1, dispFiles[i]) != 1) {
      Utils::exit("Number of sequences per file writing failed at line %d in file %s\n",
        __LINE__, __FILE__);
    }

		fclose(aacFiles[i]);
		fclose(dispFiles[i]);
	}

	/*return the number of chunks*/
	return _numSeqs;
}
/*sorting function*/
int BuildIndex::_comp(const void* a, const void* b) {
	int32_t alength = (*(const Sequence**) a)->_length;
	int32_t blength = (*(const Sequence**) b)->_length;
	alength -= blength;

	return alength > 0 ? 1 : (alength < 0 ? -1 : 0);
}
