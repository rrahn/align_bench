/*
 * AlignCoreInter.h
 *
 *  Created on: Jun 28, 2013
 *      Author: yongchao
 */

#ifndef ALIGNCOREINTER_H_
#define ALIGNCOREINTER_H_
#include "AlignCore.h"

class AlignCoreInter: public AlignCore
{
public:
	AlignCoreInter(Align* align, int dev);
	~AlignCoreInter();

	/*alignment*/
	void align(Sequence& query);

	/*allocate intermediate buffer*/
	void initialize(QueryProfile* qprofile, uint32_t queryLength);
	void finalize();

private:
	__m512i *_vecScorePrf;
	int32_t _scorePrfSize;
	__m512i * _vecHEdata;
	int32_t _vecHESize;
	__m512i* _alignScores;

	/*Smith-Waterman kernel function*/
	__attribute__((target(mic)))
	inline void swCalcScoreProfile(const __m128i* __restrict__ chunk,
				__m512i* __restrict__ profile, const __m128i* __restrict__ matrix, const __m512i vecI16)
	{
#ifdef __MIC__
   	 	register __m512i vecQ0, vecQ1, vecQ2, vecQ3;
   	 	register __m512i vecQ4, vecQ5, vecQ6, vecQ7;
		register __mmask16 vecM0, vecM1, vecM2, vecM3;
		register __mmask16 vecM4, vecM5, vecM6, vecM7;
		register __m512i vecHi, vecLo, vecS;

	    /*get the subject sequence data*/
        vecQ0 = _mm512_extload_epi32(chunk, _MM_UPCONV_EPI32_UINT8, _MM_BROADCAST32_NONE, 0);
        vecQ1 = _mm512_extload_epi32(chunk + 1, _MM_UPCONV_EPI32_UINT8, _MM_BROADCAST32_NONE, 0);
        vecQ2 = _mm512_extload_epi32(chunk + 2, _MM_UPCONV_EPI32_UINT8, _MM_BROADCAST32_NONE, 0);
        vecQ3 = _mm512_extload_epi32(chunk + 3, _MM_UPCONV_EPI32_UINT8, _MM_BROADCAST32_NONE, 0);
#if SEQ_LENGTH_ALIGN == 8
        vecQ4 = _mm512_extload_epi32(chunk + 4, _MM_UPCONV_EPI32_UINT8, _MM_BROADCAST32_NONE, 0);
        vecQ5 = _mm512_extload_epi32(chunk + 5, _MM_UPCONV_EPI32_UINT8, _MM_BROADCAST32_NONE, 0);
        vecQ6 = _mm512_extload_epi32(chunk + 6, _MM_UPCONV_EPI32_UINT8, _MM_BROADCAST32_NONE, 0);
        vecQ7 = _mm512_extload_epi32(chunk + 7, _MM_UPCONV_EPI32_UINT8, _MM_BROADCAST32_NONE, 0);
#endif

        vecM0 = _mm512_cmpge_epi32_mask(vecQ0, vecI16);
        vecM1 = _mm512_cmpge_epi32_mask(vecQ1, vecI16);
        vecM2 = _mm512_cmpge_epi32_mask(vecQ2, vecI16);
        vecM3 = _mm512_cmpge_epi32_mask(vecQ3, vecI16);
#if SEQ_LENGTH_ALIGN == 8
        vecM4 = _mm512_cmpge_epi32_mask(vecQ4, vecI16);
        vecM5 = _mm512_cmpge_epi32_mask(vecQ5, vecI16);
        vecM6 = _mm512_cmpge_epi32_mask(vecQ6, vecI16);
        vecM7 = _mm512_cmpge_epi32_mask(vecQ7, vecI16);
#endif

        /*adjust the indices*/
        vecQ0 = _mm512_mask_sub_epi32(vecQ0, vecM0, vecQ0, vecI16);
        vecQ1 = _mm512_mask_sub_epi32(vecQ1, vecM1, vecQ1, vecI16);
        vecQ2 = _mm512_mask_sub_epi32(vecQ2, vecM2, vecQ2, vecI16);
        vecQ3 = _mm512_mask_sub_epi32(vecQ3, vecM3, vecQ3, vecI16);
#if SEQ_LENGTH_ALIGN == 8
        vecQ4 = _mm512_mask_sub_epi32(vecQ4, vecM4, vecQ4, vecI16);
        vecQ5 = _mm512_mask_sub_epi32(vecQ5, vecM5, vecQ5, vecI16);
        vecQ6 = _mm512_mask_sub_epi32(vecQ6, vecM6, vecQ6, vecI16);
        vecQ7 = _mm512_mask_sub_epi32(vecQ7, vecM7, vecQ7, vecI16);
#endif

    	/*get the substitution scores*/
   	 	for(int32_t i = 0; i < SCORE_MATRIX_SIZE; ++i){
            /*get the substitution scores*/
            vecLo = _mm512_extload_epi32(matrix++, _MM_UPCONV_EPI32_SINT8, _MM_BROADCAST32_NONE, 0);
            vecHi = _mm512_extload_epi32(matrix++, _MM_UPCONV_EPI32_SINT8, _MM_BROADCAST32_NONE, 0);

            vecS = _mm512_permutevar_epi32(vecQ0, vecLo);
            vecS = _mm512_mask_permutevar_epi32(vecS, vecM0, vecQ0, vecHi);
			_mm512_store_epi32(profile++, vecS);

            vecS = _mm512_permutevar_epi32(vecQ1, vecLo);
            vecS = _mm512_mask_permutevar_epi32(vecS, vecM1, vecQ1, vecHi);
			_mm512_store_epi32(profile++, vecS);

            vecS = _mm512_permutevar_epi32(vecQ2, vecLo);
            vecS = _mm512_mask_permutevar_epi32(vecS, vecM2, vecQ2, vecHi);
			_mm512_store_epi32(profile++, vecS);

            vecS = _mm512_permutevar_epi32(vecQ3, vecLo);
            vecS = _mm512_mask_permutevar_epi32(vecS, vecM3, vecQ3, vecHi);
			_mm512_store_epi32(profile++, vecS);

#if SEQ_LENGTH_ALIGN == 8
            vecS = _mm512_permutevar_epi32(vecQ4, vecLo);
            vecS = _mm512_mask_permutevar_epi32(vecS, vecM4, vecQ4, vecHi);
			_mm512_store_epi32(profile++, vecS);

            vecS = _mm512_permutevar_epi32(vecQ5, vecLo);
            vecS = _mm512_mask_permutevar_epi32(vecS, vecM5, vecQ5, vecHi);
			_mm512_store_epi32(profile++, vecS);

            vecS = _mm512_permutevar_epi32(vecQ6, vecLo);
            vecS = _mm512_mask_permutevar_epi32(vecS, vecM6, vecQ6, vecHi);
			_mm512_store_epi32(profile++, vecS);

            vecS = _mm512_permutevar_epi32(vecQ7, vecLo);
            vecS = _mm512_mask_permutevar_epi32(vecS, vecM7, vecQ7, vecHi);
			_mm512_store_epi32(profile++, vecS);
#endif
		}
#endif
	}

	__attribute__((target(mic))) void swKernelScoreProfile(const int8_t* query, const int32_t queryLength, const __m128i* __restrict__ chunk,
        __m512i* __restrict__ vecScorePtr, const __m128i* __restrict__ matrix, const int32_t chunkLength,
      	__m512i* __restrict__ vecHEdata, __m512i* __restrict__ vecAlnScores,
        const __m512i vecGapOE, const __m512i vecGapExtend, const __m512i vecZero, const __m512i vecI16);

	__attribute__((target(mic))) void swKernelQueryProfile(const int32_t queryLength, const __m128i* __restrict__ chunk,
        const __m128i* __restrict__ qprofile, const int32_t chunkLength,
        __m512i* __restrict__ vecHEdata, __m512i* __restrict__ vecAlnScores,
        const __m512i vecGapOE, const __m512i vecGapExtend, const __m512i vecZero, const __m512i vecI16);

	__attribute__((target(mic))) void smithWaterman(const int32_t numMicThreads,
    const int8_t* __restrict__ chunks, const uint64_t* __restrict__ chunksOffs, const uint64_t numChunks,
    const uint64_t firstAddrOff, const int8_t* __restrict__ qprofile, const int8_t* __restrict__ queryData, int32_t queryLength,
    __m512i* __restrict__ vecScorePrf, const __m128i* __restrict__ vecMatrix, __m512i* __restrict__ vecHEdata, __m512i* __restrict__ chunksOutput,
    const int32_t gapOE, const int32_t gapExtend);

};

#endif /* ALIGNCOREINTER_H_ */
