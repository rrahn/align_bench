/*
 * QueryProfile.h
 *
 *  Created on: Jun 21, 2013
 *      Author: yongchao
 */

#ifndef QUERYPROFILE_H_
#define QUERYPROFILE_H_
#include "Macros.h"
#include "Utils.h"
#include "Sequence.h"

struct QueryProfile {
	QueryProfile(Sequence& query, int8_t* matrix, int32_t compMode) {
		if (compMode == INTRA_TASK_MODEL) {
			_stripedQueryProfile(query, matrix);
		}else{
			_sequentialQueryProfile(query, matrix);
		}
	}
	~QueryProfile() {
		if (_data) {
			_mm_free(_data);
		}
	}

	uint32_t _width; /*width of the query profile*/
	uint32_t _height; /*height of the query profile*/
	int8_t* _data; /*data of the query profile*/

public:

	/*build a sequential query profile*/
	void _sequentialQueryProfile(Sequence& query, int8_t *matrix) {
		int8_t* ptr, *mptr;
		uint8_t base;
		uint32_t row, col;

		_width = 32; /*each row is aligned to 32-byte boundary*/
		_height = (query._length + 1) >> 1 << 1; /*aligned to 2 so that the profile is aligned to 64-byte boundary*/
		_data = (int8_t*) _mm_malloc(_width * _height, 64);
		if (!_data) {
			Utils::exit("Memory allocation failed at line %d in file %s\n",
					__LINE__, __FILE__);
		}

		/*set the substitution scores*/
		for (row = 0; row < query._length; ++row) {
			ptr = _data + row * _width;
			base = query._bases[row];
			for (col = 0; col < 32; ++col) {
				*ptr++ = matrix[base * 32 + col];
			}
		}

		/*set the remaining elements to zero*/
		for (; row < _height; ++row) {
			memset(_data + row * _width, 0, _width * sizeof(int8_t));
		}
#if 0
		for(row = 0; row < query._length; ++row){
			Utils::log("row: %d\n", row);
			for(col = 0; col < 32; ++col){
				Utils::log("%d ", *(_data + row * _width + col));
			}
			Utils::log("\n");
		}
#endif
	}

	/*build a striped query profile*/
	void _stripedQueryProfile(Sequence& query, int8_t* matrix) {
		int32_t segSize, count;
		uint32_t length = query._length;
		int8_t* dataRow, score;
		uint8_t* bases;

		/*calculate the query profile width and height*/
		bases = query._bases;	/*get the sequence bases*/
		segSize = (length + 15) >> 4;	/*16 vector lanes*/
		count = segSize *16;
		_width = (count + 63) >> 6 << 6;	/*aligned to 64-byte boundary*/
		_height = SCORE_MATRIX_SIZE;
		_data = (int8_t*) _mm_malloc(_width * _height, 64);
		if (!_data) {
			Utils::exit("Memory allocation failed at line %d in file %s\n",
					__LINE__, __FILE__);
		}

		/* Fill in the byte query profile */
		for(int32_t i = 0; i < _height; ++i){
			dataRow = _data + i * _width;	/*assured to be aligned to 64-byte boundary*/
			for(int32_t j = 0; j < segSize; ++j){
				for(int32_t k = j; k < count; k += segSize){
					if(k >= length){
						score = 0;
					}else{
						score = matrix[i * 32 + bases[k]];
					}
					*dataRow++ = score;
				}
			}
		}
#if 0
		for(int32_t i = 0; i < _height; ++i){
			dataRow = _data + i * _width;
			for(int32_t j = 0; j < count; ++j){
				Utils::log("%d ", dataRow[j]);
			}
			Utils::log("\n");
		}
#endif
	}
};

#endif /* QUERYPROFILE_H_ */
