/*
 * Align.cpp
 *
 *  Created on: Jun 19, 2013
 *      Author: yongchao
 */

#include "Align.h"
#include "Matrix.h"
#include "SeqFileParser.h"
#include "QueryProfile.h"
#include "AlignCoreInter.h"
#include "AlignCoreIntra.h"
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

void Align::_printUsage() {
	Utils::log("Usage: swaphi align [options]\n");
	Utils::log("Input:\n");
	Utils::log("\t-q <str> (input query sequence file)\n");
	Utils::log("\t-d <str> (prefix of database file index)\n");

	Utils::log("Model:\n");
	Utils::log(
			"\t-i <int> (parallelization model, default = %d)\n");
	Utils::log(
			"\t    %d: inter-task model with one vector lane computing one sequence pair\n",
			INTER_TASK_MODEL);
	Utils::log(
			"\t    %d: intra-task model with all vector lanes computing one sequence pair\n",
			INTRA_TASK_MODEL);

	Utils::log("Scoring scheme:\n");
	Utils::log("\t-m <str> (scoring matrix name, default = %s)\n",
			_matrixName.c_str());
	Utils::log("\t-g <int> (gap open penalty, default = %d)\n", _gapOpen);
	Utils::log("\t-e <int> (gap extension penalty, default = %d)\n",
			_gapExtend);

	Utils::log("Compute:\n");
	Utils::log("\t-p <int> (sequence profile used for inter-task model, default = %d)\n", _useQueryProfile);
	Utils::log("\t    0: score profile\n");
	Utils::log("\t    1: query profile\n");
	Utils::log(
			"\t-c <int> (maximum bytes per data fetch by a device, default = %d)\n",
			_maxBytesPerFetch);
	Utils::log("\t-t <int> (number of threads per Xeon Phi, deafult = %d)\n",
			_numMicThreads);
	Utils::log("\t-x <int> (number of Xeon Phis used, default = %d)\n",
			_numXeonPhis);
	Utils::log("\t-l <int> (load the database entirely onto the device, default = %d)\n", _loadEntirely);
	Utils::log("\t-k <int> (number of top alignments reported, default = %d)\n", _numTopHits);
}
static __attribute__((target(mic))) int chk_target()
{
    int retval;

    #ifdef __MIC__
        retval = 1;
    #else
        retval = 0;
    #endif

    // Return 1 if target available
    return retval;
}
Align::Align(int argc, char* argv[]) {

	int ch;
	int val;
	double stime, etime;

	_setDefaults();	/*set defaults*/


	/*check the number of Xeon Phi devices*/
#ifdef __INTEL_OFFLOAD
	_numXeonPhis = _Offload_number_of_devices();
#endif
	if (_numXeonPhis < 1) {
		Utils::exit("Intel Xeon Phi devices unavailable\n");
	} else {
		Utils::log("Number of Xeon Phi devices installed: %d\n", _numXeonPhis);
	}

	/*check parameters*/
	if (argc < 3) {
		_printUsage();
		exit(0);
	}

	/*check the usability of the device*/
	Utils::log("Check the usability of each Xeon Phi device\n");
	int targetOk, i;
#pragma noinline
	for(i = 0; i < _numXeonPhis; ++i){
		targetOk = 0;
		#pragma offload target (mic:i)
		targetOk = chk_target();
		if(!targetOk){
			Utils::log("Failed to offload on device %d\n", i);
		}
	}

	/*parse parameters*/

	while ((ch = getopt(argc, argv, "q:d:m:g:e:c:t:p:i:l:x:k:")) >= 0) {
		switch (ch) {
		case 'q':
			_queryFileName = optarg;
			break;
		case 'd':
			_dbFilePrefix = optarg;
			break;
		case 'm':
			_matrixName = optarg;
			break;
		case 'g':
			val = atoi(optarg);
			if (val < 0) {
				val = 0;
			}
			_gapOpen = val;
			break;
		case 'e':
			val = atoi(optarg);
			if (val < 0) {
				val = 0;
			}
			_gapExtend = val;
			break;
		case 'c':
			val = atoi(optarg);
			if (val < 1) {
				val = 1;
			}
			_maxBytesPerFetch = val;
			Utils::log("_maxBytesPerFetch: %ld\n", _maxBytesPerFetch);
			break;
		case 't':
			val = atoi(optarg);
			if (val < 1) {
				val = 1;
			}
			_numMicThreads = val;
			break;
		case 'x':
			val = atoi(optarg);
			if (val < 1) {
				val = 1;
			}
			if (val > _numXeonPhis) {
				val = _numXeonPhis;
			}
			_numXeonPhis = val;
			break;
		case 'i':
			val = atoi(optarg);
			_compMode =
					val == 0 ?
							INTER_TASK_MODEL : INTRA_TASK_MODEL;
			break;
		case 'l':
			val = atoi(optarg);
			_loadEntirely = val ? 1 : 0;
			break;
		case 'p':
			val = atoi(optarg);
			_useQueryProfile = val ? 1 : 0;
			break;
		case 'k':
			val = max(atoi(optarg), 1);
			_numTopHits = val;
			break;
		default:
			Utils::exit("Unsupported option: %s\n", optarg);
			break;
		}
	}

	if(_compMode != INTER_TASK_MODEL){
		_useQueryProfile = 1;
	}

	if(_compMode == INTER_TASK_MODEL){
		Utils::log("Inter-task parallelization is used\n");
	}else{
		Utils::log("Intra-task parallelization is used\n");
	}

	/*check the query and database file*/
	if (_queryFileName.length() == 0) {
		Utils::exit("MUST give the query sequence file name\n");
	}
	if (_dbFilePrefix.length() == 0) {
		Utils::exit("MUST give the prefix of the database index files\n");
	}

	/*load the matrix*/
	Utils::log("Load scoring matrix\n");
	_matrix = (int8_t*)_mm_malloc(SCORE_MATRIX_SIZE * 32, 64);
	if(!_matrix){
		Utils::exit("Memory allocation failed at line %d in file %s\n", __LINE__, __FILE__);
	}
	Matrix::getMatrix(_matrixName.c_str(), _matrix);

	/*map database sequences in memory*/
	Utils::log("load database from file\n");
	stime = Utils::getSysTime();
	_memMapDatabase(_dbFilePrefix);
	etime = Utils::getSysTime();
	Utils::log("Taken %f seconds to load the database\n", etime - stime);

	/*re-set the maximum million bytes per fetch*/
	uint64_t value = (_maxLength + 15) >> 4 << 4;
	if (_maxBytesPerFetch < value) {
		_maxBytesPerFetch = value;
		Utils::log("Ajusted maximum bytes per fetch is %ld\n", _maxBytesPerFetch);
	}
	/*run the alignment*/
	Utils::log(
			"Run the alignment with %d Xeon Phis (with each having %d threads)\n",
			_numXeonPhis, _numMicThreads);

	/*initialize mutex*/
	pthread_mutex_init(&_mutex, NULL);

	/*run the kernel*/
	run();
}
Align::~Align() {

	/*release the mutex*/
	pthread_mutex_destroy(&_mutex);

	/*unmap database sequences out of memory*/
	_memUnmapDatabase();

	/*scoring matrix*/
	if(_matrix){
		_mm_free(_matrix);
	}

	/*alignment score*/
	if(_alignScores){
		_mm_free(_alignScores);
	}

	if(_alignIndices){
		_mm_free(_alignIndices);
	}

}

void Align::run() {
	Sequence query;
	uint64_t first, firstAddrOff, numChunks;
	QueryProfile*qprofile;
	SeqFileParser* parser;
	vector<AlignCore*> alignCores (_numXeonPhis, NULL);
	vector<ThreadParam*> threadParams (_numXeonPhis, NULL);
	vector<pthread_t> threadIDs(_numXeonPhis, NULL);

	/*generate an alignment entity for each Xeon Phi*/
	for (size_t dev = 0; dev < _numXeonPhis; ++dev) {
		/*allocate object for alignment cores*/
		if(_compMode == INTER_TASK_MODEL){
			alignCores[dev] = new AlignCoreInter(this, dev);
		}else{
			alignCores[dev] = new AlignCoreIntra(this, dev);
		}
		threadParams[dev] = new ThreadParam(dev, alignCores[dev]);
	}

	/*open the query profile*/
	parser = new SeqFileParser(_queryFileName.c_str());
	if (!parser) {
		Utils::exit("Failed to open the file %s\n", _queryFileName.c_str());
	}

	double stime, etime;
	/*iterate each query*/
	while (parser->getSeq(query)) {

		/*initialize sequence index*/
		_initAlignScoreIndices(_alignIndices);

		/*get the system time*/
		stime = Utils::getSysTime();

		/*build a query profile*/
		if(_useQueryProfile){
			qprofile = new QueryProfile(query, _matrix, _compMode);
		}

		/*initialize the alignmen cores*/
		for (int32_t dev = 0; dev < _numXeonPhis; ++dev) {
			alignCores[dev]->initialize(qprofile, query._length);
			threadParams[dev]->setQuery(&query);
		}
		/*launch multiple threads*/
		for(int32_t dev = 0; dev < _numXeonPhis; ++dev){
			if(pthread_create(&threadIDs[dev], NULL, _threadFunc, threadParams[dev]) != 0){
				Utils::exit("Thread creating failed\n");
			}
		}
		/*waiting for the completion of all threads*/
		for(int32_t dev = 0; dev < _numXeonPhis; ++dev){
			pthread_join(threadIDs[dev], NULL);
		}
		
		/*release the query profile*/
		if(_useQueryProfile){
			delete qprofile;
		}

		/*get the system time*/
		etime = Utils::getSysTime();

		/*output alignment scores*/
		_reportAlignScores(query, _alignScores, _alignIndices);
		
		/*finalize alignment cores*/
		for (int32_t dev = 0; dev < _numXeonPhis; ++dev) {
			alignCores[dev]->finalize();
		}

		double gcups = ((double)_totalNumChars) * query._length;
		gcups /= 1000000000 * (etime - stime);
		Utils::log("Runtime: %f seconds %f GCUPS\n", etime - stime, gcups);

	}

	/*delete the file parser*/
	delete parser;

	/*delete alignment core*/
	for (size_t i = 0; i < _numXeonPhis; ++i) {
		delete alignCores[i];
		delete threadParams[i];
	}
}
void Align::_reportAlignScores(Sequence& query, int32_t* alignScores, int64_t* alignIndices)
{
	uint64_t offset;
	int64_t first = _numSeqs - 1;
	int64_t last = _numSeqs < _numTopHits ? 0 : _numSeqs - _numTopHits;

	/*sort alignmnet scores*/
	KeyValueSort<int32_t, int64_t>::keyValueSort(alignScores, alignIndices, _numSeqs);

#if 0
	for(int32_t i = 0; i < _numSeqs; ++i){
		Utils::log("%d %ld\n",alignScores[i], alignIndices[i]);
	}
#endif

	/*output the top alignment scores*/
	Utils::log("Query (%d amino acids): %s\n", query._length, query._name);
	for(int64_t i = first; i >= last; --i){
		Utils::log("score %d: %s\n", alignScores[i], _ttl + _tof[alignIndices[i]]);
	}
}
void * Align::_threadFunc(void* arg)
{
	ThreadParam* params = (ThreadParam*)arg;

	params->_alignCore->align(*(params->_query));

	return NULL;
}
uint64_t Align::getWorkloadPerBatch(uint64_t& first, uint64_t& firstAddrOff, int32_t micIndex) {

	uint64_t numChunks = 0;
	list<WorkloadEntry>& workload = _workloads[micIndex];

	if(workload.size() > 0){
		WorkloadEntry& entry = workload.front();
		first = entry._first;
		firstAddrOff = entry._firstAddrOff;
		numChunks = entry._numChunks;
		workload.pop_front();
	}

	return numChunks;
}
void Align::_setDefaults() {

	/*set the compute mode*/
	_compMode = INTER_TASK_MODEL; /*inter-task parallelization*/

	/*set scoring matrix*/
	_matrixName = "blosum62";
	_gapOpen = 10;
	_gapExtend = 2;

	/*alignment related*/
	_maxBytesPerFetch = MAX_BYTES_PER_FETCH;
	_alignScores = NULL;
	_numTopHits = 10;
	_useQueryProfile = 0;
	_loadEntirely = 1;

	/*number of threads per Xeon Phi*/
	_numMicThreads = 240;	/*4 * 60*/

	/*number of Xeon Phis used*/
	_numXeonPhis = 1;
}

void Align::_calcWorkloadPerBatch() {

	uint64_t totalNumChunks;
	uint64_t numChunks;
	uint64_t numBytes;
	uint64_t chunkLength;
	uint64_t maxNumBytes;
	uint64_t numChunksFetched;
	uint64_t currentAddrOff;
	uint64_t first, firstAddrOff;
	uint64_t* aofAddr;

	/*allocate space for workloads*/
	_workloads.resize(_numXeonPhis);

	for(int32_t i = 0; i < _numXeonPhis; ++i){
		list<WorkloadEntry>& workload = _workloads[i];

		numChunksFetched = 0;
		currentAddrOff = 0;
		maxNumBytes = _maxBytesPerFetch;

		totalNumChunks = _compMode == INTER_TASK_MODEL ? (_numSeqsPerFile[i] + 15) >> 4 : _numSeqsPerFile[i];
		aofAddr = _aofs[i];
		do{
			numBytes = 0;
			numChunks = 0;
			first = numChunksFetched;	/*the number of chunks that have been processed*/
			firstAddrOff = currentAddrOff;	/*get the starting position*/

			/*get the chunk length*/
			chunkLength = aofAddr[numChunksFetched + 1] - aofAddr[numChunksFetched];
			while (numChunksFetched < totalNumChunks
					&& numBytes + chunkLength <= maxNumBytes ) {
				/*advance the chunk index*/
				++numChunksFetched;

				/*advance the file pointer position*/
				currentAddrOff += chunkLength;

				/*increase the total number of bases*/
				numBytes += chunkLength;

				/*increment the number of chunks*/
				++numChunks;

				/*get the new chunk length*/
				chunkLength = aofAddr[numChunksFetched + 1] - aofAddr[numChunksFetched];
			}

			/*save the workload entry*/
			workload.push_back(WorkloadEntry(first, firstAddrOff, numChunks));

		}while(numChunks);
	}
}

void Align::_memMapDatabase(const string& dbPrefix) {
	char nameBuffer[1024];
	vector<string> aacFileNames (_numXeonPhis, ""); /*amino acid file*/
	vector<string> dispFileNames (_numXeonPhis, ""); /*displacement file*/
	string titleFileName; /*title file name*/
	string titleDispFileName; /*title  displacement file*/
	vector<int> aacFiles(_numXeonPhis, -1);
	vector<int> dispFiles(_numXeonPhis, -1);
	int titleFile, titleDispFile;

	/*generate the input file name*/
	sprintf(nameBuffer, ".np%d.ttl", _numXeonPhis);	
	titleFileName = dbPrefix + nameBuffer; /*title file name*/

	sprintf(nameBuffer, ".np%d.tof", _numXeonPhis);
	titleDispFileName = dbPrefix + nameBuffer; /*title  displacement file*/

	if(_compMode == INTER_TASK_MODEL){
		for(int32_t i = 0; i < _numXeonPhis; ++i){
			sprintf(nameBuffer, ".np%d.16.%d.aac", _numXeonPhis, i);
			aacFileNames[i] = dbPrefix + nameBuffer; /*amino acid file*/

			sprintf(nameBuffer, ".np%d.16.%d.aof", _numXeonPhis, i);
			dispFileNames[i] = dbPrefix + nameBuffer; /*displacement file*/
		}
	}else{
    for(int32_t i = 0; i < _numXeonPhis; ++i){
      sprintf(nameBuffer, ".np%d.1.%d.aac", _numXeonPhis, i);
      aacFileNames[i] = dbPrefix + nameBuffer; /*amino acid file*/

      sprintf(nameBuffer, ".np%d.1.%d.aof", _numXeonPhis, i);
      dispFileNames[i] = dbPrefix + nameBuffer; /*displacement file*/
    }
	}

	/*open the input files*/
	titleFile = open(titleFileName.c_str(), O_RDONLY);
	if (titleFile == -1) {
		Utils::exit("Failed to open file: %s and please rebuild index for %d Intel Xeon Phis\n", titleFileName.c_str(), _numXeonPhis);
	}
	titleDispFile = open(titleDispFileName.c_str(), O_RDONLY);
	if (titleDispFile == -1) {
		Utils::exit("Failed to open file: %s and please rebuild index for %d Intel Xeon Phis\n", titleDispFileName.c_str(), _numXeonPhis);
	}

	for(int32_t i = 0; i < _numXeonPhis; ++i){
		aacFiles[i] = open(aacFileNames[i].c_str(), O_RDONLY);
		if (aacFiles[i] == -1) {
			Utils::exit("Failed to open file: %s and please rebuild index for %d Intel Xeon Phis\n", aacFileNames[i].c_str(), _numXeonPhis);
		}
		dispFiles[i] = open(dispFileNames[i].c_str(), O_RDONLY);
		if (dispFiles[i] == -1) {
			Utils::exit("Failed to open file: %s and please build index for %d Intel Xeon Phis\n", dispFileNames[i].c_str(), _numXeonPhis);
		}
	}


	/*allocate spaces*/
	_aacs.resize(_numXeonPhis, NULL);
	_aacLengths.resize(_numXeonPhis, NULL);
	_numSeqsPerFile.resize(_numXeonPhis, 0);
	_aofs.resize(_numXeonPhis, NULL);
	_aofLengths.resize(_numXeonPhis, NULL);

	int8_t *addr;
	int32_t bytesPerRead;
	int64_t numBytesRead;
	int64_t off;
	for(int32_t dev = 0; dev < _numXeonPhis; ++dev){
		/*for amino acids*/
		_aacLengths[dev] = lseek64(aacFiles[dev], 0, SEEK_END);
		Utils::log("#file length: %ld\n", _aacLengths[dev]);
		if(!_loadEntirely){
			_aacs[dev] = (int8_t*) mmap64(0, _aacLengths[dev], PROT_READ, MAP_PRIVATE, aacFiles[dev], 0);
			if (_aacs[dev] == MAP_FAILED ) {
				Utils::exit("Unable to map file %s in memory (empty or too large)\n",
					aacFileNames[dev].c_str());
			}
		}else{
			_aacs[dev] = (int8_t*)_mm_malloc(_aacLengths[dev], 64);
			if(!_aacs[dev]){
				Utils::exit("Memory allocation failed at line %d in file %s\n", __LINE__,
					__FILE__);
			}
			/*read the file*/
			lseek64(aacFiles[dev], 0, SEEK_SET);

			addr = _aacs[dev];
			bytesPerRead = 0x1000;
			numBytesRead = _aacLengths[dev] / bytesPerRead * bytesPerRead;
			for(off = 0; off < numBytesRead; off += bytesPerRead){
				if(read(aacFiles[dev], addr, bytesPerRead) != bytesPerRead){
						Utils::exit("Filed read failed at line %d in file %s\n", __LINE__,
						__FILE__);
				}
				addr += bytesPerRead;
			}
			bytesPerRead = _aacLengths[dev] - numBytesRead;
			if(bytesPerRead){
        if(read(aacFiles[dev], addr, bytesPerRead) != bytesPerRead){
            Utils::exit("Filed read failed at line %d in file %s \n", __LINE__,
            __FILE__);
        }
				off += bytesPerRead;
			}
			if(off != _aacLengths[dev]){
				Utils::exit("The number of bytes read %ld is not equal to the number of bytes %ld\n",
					off, _aacLengths[dev]);
			}
		}

		/*for amino acid displacement*/
		_aofLengths[dev] = lseek64(dispFiles[dev], 0, SEEK_END);
		if(!_loadEntirely){
			_aofs[dev] = (uint64_t*) mmap(0, _aofLengths[dev], PROT_READ, MAP_PRIVATE, dispFiles[dev], 0);
			if (_aofs[dev] == MAP_FAILED ) {
				Utils::exit("Unable to map file %s in memory (empty or too large)\n",
					dispFileNames[dev].c_str());
			}
		}else{
			_aofs[dev] = (uint64_t*)_mm_malloc(_aofLengths[dev], 64);
			if(!_aofs[dev]){
            Utils::exit("Memory allocation failed at line %d in file %s\n", __LINE__,
                __FILE__);
			}
			/*read the file*/
			lseek64(dispFiles[dev], 0, SEEK_SET);
	
			addr = (int8_t*)_aofs[dev];
			bytesPerRead = 0x1000;
			numBytesRead = _aofLengths[dev] / bytesPerRead * bytesPerRead;
			for(off = 0; off < numBytesRead; off += bytesPerRead){
				if(read(dispFiles[dev], addr, bytesPerRead) != bytesPerRead){
  	          Utils::exit("Filed read failed at line %d in file %s\n", __LINE__,
                __FILE__);
				}
				addr += bytesPerRead;
			}
			bytesPerRead = _aofLengths[dev] - numBytesRead;
			if(bytesPerRead){
        if(read(dispFiles[dev], addr, bytesPerRead) != bytesPerRead){
              Utils::exit("Filed read failed at line %d in file %s\n", __LINE__,
                __FILE__);
        }
				off += bytesPerRead;
			}
			if(off != _aofLengths[dev]){
				Utils::exit("The number of bytes read %ld is not equal to the number of bytes %ld\n",
							off, _aofLengths[dev]);
			}
		}
	}

	/*for sequence title*/
	_ttlLength = lseek64(titleFile, 0, SEEK_END);
	_ttl = (int8_t*) mmap(0, _ttlLength, PROT_READ, MAP_PRIVATE, titleFile, 0);
	if (_ttl == MAP_FAILED ) {
		Utils::exit("Unable to map file %s in memory (empty or too large)\n",
				titleFileName.c_str());
	}

	/*for sequence title displacement*/
	_tofLength = lseek64(titleDispFile, 0, SEEK_END);
	_tofAddr = (uint64_t*) mmap(0, _tofLength, PROT_READ, MAP_PRIVATE,
			titleDispFile, 0);
	if (_tofAddr == MAP_FAILED ) {
		Utils::exit("Unable to map file %s in memory (empty or too large)\n",
				titleDispFileName.c_str());
	}
	_tof = _tofAddr + 4; /*skip the number of sequences, minimum length, maximum length, and the total number of characters*/

	/*get the number of sequences*/
	_numSeqs = *_tofAddr;
	if (_numSeqs == 0) {
		Utils::exit("Empty database file and will exit right now\n");
	}
	/*calculate the number of chunks*/
	_numChunks = _compMode == INTER_TASK_MODEL ? ((_numSeqs + 15) >> 4) : _numSeqs;

	/*get the minimum sequence length*/
	_minLength = *(_tofAddr + 1);

	/*get the maximum sequence length*/
	_maxLength = *(_tofAddr + 2);

	/*get the total number of characters*/
	_totalNumChars = *(_tofAddr + 3);

	/*get the number of characters in each file*/
	for(int32_t i = 0; i < _numXeonPhis; ++i){
		_numSeqsPerFile[i] = _aofs[i][_aofLengths[i] / sizeof(uint64_t) - 1];
		Utils::log("Number of sequences for Intel Xeon Phi %d: %ld\n", i, _numSeqsPerFile[i]);
	}
	Utils::log("numSeqs: %ld numChunks: %ld minLength: %ld maxLength: %ld totalNumAminoAcids: %ld\n",
			_numSeqs, _numChunks, _minLength, _maxLength, _totalNumChars);

	/*close the input files*/
	for(int32_t i = 0; i < _numXeonPhis; ++i){
		close(aacFiles[i]);
		close(dispFiles[i]);
	}
	close(titleFile);
	close(titleDispFile);

	/*allocate alignment scores*/
	_allocAlignScores();


	/*allocate workload*/
	_calcWorkloadPerBatch();
}
void Align::_allocAlignScores()
{
	uint64_t offset = 0;
	uint64_t dist = 0;

	_alignScoresAddrs.resize(_numXeonPhis, NULL);

	/*allocate alignmen score buffer*/
  if(_compMode == INTER_TASK_MODEL){
    _alignScores = (int32_t*)_mm_malloc(_numChunks * 16 * sizeof(_alignScores[0]), 64);
		_alignIndices = (int64_t*)_mm_malloc(_numChunks * 16 * sizeof(_alignIndices[0]), 64);
  }else{
    _alignScores = (int32_t*)_mm_malloc(_numChunks * sizeof(_alignScores[0]), 64);
		_alignIndices = (int64_t*)_mm_malloc(_numChunks * sizeof(_alignIndices[0]), 64);
  }
  if(!_alignScores || !_alignIndices){
    Utils::exit("Memory allocation failed at line %d in file %s\n", __LINE__, __FILE__);
  }
	
	/*calculate the starting addresses of each Xeon Phi device*/
	for(int32_t i = 0; i < _numXeonPhis; ++i){
		_alignScoresAddrs[i] = _alignScores + offset;

		dist = _numSeqsPerFile[i];
		if(_compMode == INTER_TASK_MODEL){
			/*calculate the aligned number of sequences*/
			dist = (dist + 15) >> 4 << 4;
		}
		offset += dist;
		//Utils::log("dist: %ld offset: %ld\n", dist, offset);
	}
}
void Align::_initAlignScoreIndices(int64_t *alignIndices)
{
	uint64_t offset = 0;
	uint64_t numChunks;
	int64_t *addr;

	for(int32_t micIndex = 0; micIndex < _numXeonPhis; ++micIndex){

		/*calculate the aligned number of sequences*/
		addr = alignIndices + offset;
		numChunks = _numSeqsPerFile[micIndex];
		if(_compMode == INTER_TASK_MODEL){
			numChunks = (numChunks + 15) >> 4;
			for(uint64_t index = 0; index < numChunks; ++index){
				uint64_t baseIndex = (index * _numXeonPhis + micIndex) * 16;
				for(int32_t i = 0; i < 16; ++i){
					*addr = baseIndex + i;
					//Utils::log("micIndex: %d index: %ld %ld\n", micIndex, index, *addr);
					addr++;
				}
			}
			offset += numChunks * 16;
		}else{
			for(uint64_t index = 0; index < numChunks; ++index){
				/*fill the index*/
				*addr = index * _numXeonPhis + micIndex;
				++addr;
			}
			/*move to the next slot*/
			offset += numChunks;
		}
	}
}

void Align::_memUnmapDatabase() {
	for(int32_t i = 0; i < _numXeonPhis; ++i){
		if(_loadEntirely){
			_mm_free(_aacs[i]);
		}else{
			munmap(_aacs[i], _aacLengths[i]);
		}
	}
	for(int32_t i = 0; i < _numXeonPhis; ++i){
		if(_loadEntirely){
			_mm_free(_aofs[i]);
		}else{
			munmap(_aofs[i], _aofLengths[i]);
		}
	}
	if (_ttl) {
		munmap(_ttl, _ttlLength);
	}

	if (_tofAddr) {
		munmap(_tofAddr, _tofLength);
	}
}

