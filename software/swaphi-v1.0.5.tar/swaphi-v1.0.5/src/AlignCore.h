/*
 * AlignCore.h
 *
 *  Created on: Jun 21, 2013
 *      Author: yongchao
 */

#ifndef ALIGNCORE_H_
#define ALIGNCORE_H_
#include "Macros.h"
#include "Utils.h"
#include "Align.h"
#include "QueryProfile.h"


class AlignCore {
public:
	AlignCore(Align* align, int32_t micIndex);
	virtual ~AlignCore(){};

	/*alignment*/
	virtual void align(Sequence& query){}

	/*allocate intermediate buffer*/
	virtual void initialize(QueryProfile* qprofile, uint32_t queryLength){}
	virtual void finalize(){}

protected:
	Align *_align;
	int32_t _numMicThreads;
	int32_t _gapOE;
	int32_t _gapExtend;
	int8_t* _matrix;
	int32_t _useQueryProfile;
	int32_t _micIndex;
	int8_t* _qprofile;
  int32_t _qprofileSize;
	int32_t _qprofileWidth;

	/*database information*/
	int8_t *_aac; /*amino acids*/
	uint64_t *_aof; /*amino acid displacement*/
	int8_t* _ttl; /*titles*/
	uint64_t *_tof;/*title displacement*/

	/*static functions*/
	__attribute__((target(mic)))
	void printVector(int32_t tid, const __m512i vec);
};

struct ThreadParam
{
	ThreadParam(int32_t tid, AlignCore* alignCore)
	{
		_tid = tid;
		_alignCore = alignCore;
	}
	void setQuery(Sequence* query)
	{
		_query = query;
	}

	/*member variables*/
	int32_t _tid;
	Sequence* _query;
	AlignCore* _alignCore;
};

#endif /* ALIGNCORE_H_ */
