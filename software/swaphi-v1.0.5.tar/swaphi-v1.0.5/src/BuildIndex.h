/*
 * BuildIndex.h
 *
 *  Created on: Jun 19, 2013
 *      Author: yongchao
 */

#ifndef BUILDINDEX_H_
#define BUILDINDEX_H_

#include "Macros.h"
#include "Utils.h"
#include "Sequence.h"

class BuildIndex {
public:
	BuildIndex(int argc, char* argv[]);
	~BuildIndex();

private:
	string _inputFile;
	string _outPrefix;
	Sequence**_sequences;
	uint64_t _numSeqs;
	uint64_t _totalNumChars;
	uint32_t _minLength;
	uint32_t _maxLength;
	uint32_t _maxAllowableLength;
	uint32_t _minAllowableLength;
	uint64_t _maxNumSeqs;
	int32_t _numXeonPhis;
	uint64_t _getNumSeqs(const char* fileName);

	/*build sequence name index*/
	void _buildSeqNameIndex();

	/*build 16-lane indices*/
	uint64_t _pacSeqsVL16();

	/*build single lane indices*/
	uint64_t _plainSeqs();

	/*sequence filter*/
	inline bool _qualified(uint32_t length){
		return (length >= _minAllowableLength && length <= _maxAllowableLength);
	}

	void _printUsage();
	static int _comp(const void* a, const void* b);
};

#endif /* BUILDINDEX_H_ */
