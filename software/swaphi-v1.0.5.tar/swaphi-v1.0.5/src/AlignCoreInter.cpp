/*
 * AlignCoreInter.cpp
 *
 *  Created on: Jun 28, 2013
 *      Author: yongchao
 */

#include "AlignCoreInter.h"

AlignCoreInter::AlignCoreInter(Align* align, int32_t micIndex) :
		AlignCore(align, micIndex) {
	_vecHEdata = NULL;
	_vecScorePrf = NULL;
	_alignScores = (__m512i*)align->getAlignScoreAddr(_micIndex);
}
AlignCoreInter::~AlignCoreInter() {
	if (_vecHEdata) {
		_mm_free(_vecHEdata);
	}
	if(_vecScorePrf){
		_mm_free(_vecScorePrf);
	}
}
void AlignCoreInter::initialize(QueryProfile* qprofile,
		uint32_t queryLength) {

	if(_useQueryProfile){
		/*set query profile*/
		_qprofile = qprofile->_data;
		_qprofileSize = qprofile->_width * qprofile->_height;
	}else{
		/*score profile*/	
		_scorePrfSize = SCORE_MATRIX_SIZE * 8 * _numMicThreads;
		_vecScorePrf = (__m512i*)_mm_malloc(_scorePrfSize * sizeof(__m512i), 64);
	}
	/*allocate host buffer*/
	_vecHESize = queryLength * _numMicThreads * 2;
	_vecHEdata = (__m512i *) _mm_malloc(_vecHESize * sizeof(__m512i ), 64); /*dummy allocation*/
}
void AlignCoreInter::finalize() {
	if (_vecHEdata) {
		_mm_free(_vecHEdata);
		_vecHEdata = NULL;
	}
	if(_vecScorePrf){
		_mm_free(_vecScorePrf);
		_vecScorePrf = NULL;
	}
}
void AlignCoreInter::align(Sequence& query)
{
	uint32_t queryLength = query._length; /*get the query length*/
	/*allocate output buffer*/

	/*prepare pointers for the offload*/
	int8_t* qprofile = _qprofile;
	__m512i* vecHEdata = _vecHEdata;
	__m128i* vecMatrix = (__m128i*)_matrix;
	__m512i* vecScorePrf = _vecScorePrf;
	int8_t * queryData = (int8_t*)query._bases;
	uint64_t first, firstAddrOff;
	uint64_t numChunks;

	if(_useQueryProfile){
#pragma offload target(mic:_micIndex) \
        in(qprofile: length(_qprofileSize) MIC_ALLOC) \
        nocopy(vecHEdata: length(_vecHESize) MIC_ALLOC) 
		{
			/*do nothing*/
		}

	}else{
#pragma offload target(mic:_micIndex) \
		in(vecMatrix: length(SCORE_MATRIX_SIZE * 2) MIC_ALLOC) \
		in(queryData: length(query._length) MIC_ALLOC) \
		nocopy(vecScorePrf: length(_scorePrfSize) MIC_ALLOC) \
  	nocopy(vecHEdata: length(_vecHESize) MIC_ALLOC)
		{
			/*do nothing*/
		}
	}

	double stime, etime;
	stime = Utils::getSysTime();
	while((numChunks = _align->getWorkloadPerBatch(first, firstAddrOff, _micIndex)) > 0){
		/*calculate relevant data*/
		uint64_t last = first + numChunks;
		uint64_t numBytesChunks = _aof[last] - _aof[first];
		int8_t* __restrict__ chunks = _aac + firstAddrOff; /*the starting address of the chunk data*/
		uint64_t* __restrict__ chunksOffs = _aof + first; /*the starting address of the offsets*/
		__m512i* __restrict__ chunksOutput = _alignScores + first;

		Utils::log("micIndex: %d first: %ld numChunks %ld firstAddrOff: %ld numBytesChunks %ld\n", _micIndex, first, numChunks, firstAddrOff, numBytesChunks);

		/*perform alignment on the batch of chunks*/

		if(_useQueryProfile){
#pragma offload target(mic:_micIndex) \
			in(chunks:length(numBytesChunks) MIC_ALLOC_FREE) \
   		in(chunksOffs:length(numChunks + 1) MIC_ALLOC_FREE)  \
			nocopy(qprofile: MIC_REUSE) \
			nocopy(vecHEdata: length(_vecHESize) MIC_REUSE) \
			out(chunksOutput:length(numChunks) MIC_ALLOC_FREE)
			{
				smithWaterman(_numMicThreads, chunks, chunksOffs, numChunks, firstAddrOff, qprofile, NULL, query._length,
					NULL, NULL, vecHEdata, chunksOutput, _gapOE, _gapExtend);
			}	
		}else{
#pragma offload target(mic:_micIndex) \
            in(chunks:length(numBytesChunks) MIC_ALLOC_FREE) \
            in(chunksOffs:length(numChunks + 1) MIC_ALLOC_FREE)  \
            nocopy(vecMatrix: MIC_REUSE) \
            nocopy(queryData: MIC_REUSE) \
            nocopy(vecScorePrf: MIC_REUSE) \
            nocopy(vecHEdata: length(_vecHESize) MIC_REUSE) \
            out(chunksOutput:length(numChunks) MIC_ALLOC_FREE)
            {
                smithWaterman(_numMicThreads, chunks, chunksOffs, numChunks, firstAddrOff, NULL, queryData, query._length,
                vecScorePrf, vecMatrix, vecHEdata, chunksOutput, _gapOE, _gapExtend);
            }
		}
	}
	etime = Utils::getSysTime();
	Utils::log("Xeon Phi %d takes: %f seconds\n", _micIndex, etime - stime);


	if(_useQueryProfile){
#pragma offload target(mic:_micIndex) \
        nocopy(qprofile: MIC_FREE) \
        nocopy(vecHEdata: MIC_FREE) 
		{
			/*do nothing*/
		}
	}else{
#pragma offload target(mic:_micIndex) \
		nocopy(vecMatrix: MIC_FREE) \
		nocopy(queryData: MIC_FREE) \
		nocopy(vecScorePrf: MIC_FREE) \
        nocopy(vecHEdata: MIC_FREE) 
		{
			/*do nothing*/
		}
	}
}
__attribute__((target(mic))) void AlignCoreInter::smithWaterman(const int32_t numMicThreads,
	const int8_t* __restrict__ chunks, const uint64_t* __restrict__ chunksOffs, const uint64_t numChunks,
	const uint64_t firstAddrOff, const int8_t* __restrict__ qprofile, const int8_t* __restrict__ queryData, int32_t queryLength,
	__m512i* __restrict__ vecScorePrf, const __m128i* __restrict__ vecMatrix, __m512i* __restrict__ vecHEdata, __m512i* __restrict__ chunksOutput,
	const int32_t gapOE, const int32_t gapExtend)
{
#ifdef __MIC__
	int32_t ichunk;
	register __m512i vecGapExtend, vecGapOE, vecZero, vecI16;
	
	/*set the number of threads*/
	omp_set_num_threads(numMicThreads);
	//printf("numthreads: %d numChunks: %ld\n", numMicThreads, numChunks);

	/*generate the gap extend penalty*/
	vecGapExtend = _mm512_set_epi32(gapExtend, gapExtend, gapExtend, gapExtend,
		gapExtend, gapExtend, gapExtend, gapExtend, gapExtend, gapExtend,
		gapExtend, gapExtend, gapExtend, gapExtend, gapExtend, gapExtend);

	/*generate the sum of gap open and extension penalties*/
	vecGapOE = _mm512_set_epi32(gapOE, gapOE, gapOE, gapOE, gapOE, gapOE,
		gapOE, gapOE, gapOE, gapOE, gapOE, gapOE, gapOE, gapOE, gapOE,
		gapOE);

	vecI16 = _mm512_set_epi32(16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16);
	vecZero = _mm512_setzero_epi32();


#pragma omp parallel for private(ichunk) default(shared) schedule(guided, 1)
	for (ichunk = 0; ichunk < numChunks; ++ichunk) {

		/*get the thread index on the device*/
		int32_t tid = omp_get_thread_num();

		/*get the subject sequence length*/
		int32_t chunkLength = (chunksOffs[ichunk + 1]
				- chunksOffs[ichunk]) >> 4;

		/*get the offset of the subject sequence length*/
		int32_t offset = chunksOffs[ichunk] - firstAddrOff;

		//printf("offset: %d firstAddrOff: %ld %ld\n", offset, firstAddrOff, chunksOffs[ichunk]);
		if(qprofile != NULL){
			/*use query profile*/
			swKernelQueryProfile(queryLength, (__m128i*)(chunks + offset), (__m128i*)qprofile, chunkLength,
				vecHEdata + tid * queryLength * 2, chunksOutput + ichunk,
				vecGapOE, vecGapExtend, vecZero, vecI16);
		}else{
			/*do not use query profile*/
			swKernelScoreProfile(queryData, queryLength, (__m128i*)(chunks + offset),
				vecScorePrf + tid * SCORE_MATRIX_SIZE * 8, vecMatrix, chunkLength,
               	vecHEdata + tid * queryLength * 2, chunksOutput + ichunk,
                vecGapOE, vecGapExtend, vecZero, vecI16);
		}
	}
#endif
}

__attribute__((target(mic))) void AlignCoreInter::swKernelScoreProfile(const int8_t* query, const int32_t queryLength, const __m128i* __restrict__ chunk,
		__m512i* __restrict__ vecScorePrf, const __m128i* __restrict__ matrix, const int32_t chunkLength, __m512i* __restrict__ vecHEdata, __m512i* __restrict__ vecAlnScores,
		const __m512i vecGapOE, const __m512i vecGapExtend, const __m512i vecZero, const __m512i vecI16)
		{
			register __m512i vecQ0, vecQ1, vecQ2, vecQ3, vecQ4, vecQ5, vecQ6, vecQ7;
			register __m512i vecS0, vecS1, vecS2, vecS3, vecS4, vecS5, vecS6, vecS7;
			register __m512i vecH, vecE, vecMax;
			register __m512i h0, f0, h1, f1, h2, f2, h3, f3;
			register __m512i d0, d1, d2, d3;
			register __mmask16 vecM0, vecM1, vecM2, vecM3, vecM4, vecM5, vecM6, vecM7;
			__m512i* __restrict__ vecHE;
			const __m512i* __restrict__ profile;

#if SEQ_LENGTH_ALIGN == 8
			register __m512i h4, f4, h5, f5, h6, f6, h7, f7;
			register __m512i d4, d5, d6, d7;
#endif

#ifdef __MIC__

	/*clear the memory*/
	memset(vecHEdata, 0, queryLength * sizeof(__m512i) * 2);

	/*core loop*/
	vecMax = vecZero;
	for (int32_t row = 0; row < chunkLength; row += SEQ_LENGTH_ALIGN) { /*target on the row*/

		/*initialize*/
		f0 = f1 = f2 = f3 = vecZero;
		h0 = h1 = h2 = h3 = vecZero;
		d0 = d1 = d2 = d3 = vecZero;
#if SEQ_LENGTH_ALIGN == 8
		f4 = f5 = f6 = f7 = vecZero;
		h4 = h5 = h6 = h7 = vecZero;
		d4 = d5 = d6 = d7 = vecZero;
#endif
		/*calculate the score profile*/
		swCalcScoreProfile(chunk, vecScorePrf, matrix, vecI16);
		chunk += 8;

		/*the inner core loop*/
		vecHE = vecHEdata;
		for (int32_t col = 0; col < queryLength; ++col) { /*query on the column*/
			/*get the substitution scores*/
			profile = vecScorePrf + query[col] * 8;
			vecS0 = _mm512_load_epi32(profile);
			vecS1 = _mm512_load_epi32(profile + 1);
			vecS2 = _mm512_load_epi32(profile + 2);
			vecS3 = _mm512_load_epi32(profile + 3);
			vecS4 = _mm512_load_epi32(profile + 4);
			vecS5 = _mm512_load_epi32(profile + 5);
			vecS6 = _mm512_load_epi32(profile + 6);
			vecS7 = _mm512_load_epi32(profile + 7);

			/*get the H and E values*/
			vecH = _mm512_load_epi32(vecHE);	/*must be 64-byte-aligned*/
			vecE = _mm512_load_epi32(vecHE + 1);	/*must be 64-byte-aligned*/

			/*compute the new F value*/
			f0 = _mm512_max_epi32(_mm512_add_epi32(f0, vecGapExtend), _mm512_add_epi32(h0, vecGapOE));
			f1 = _mm512_max_epi32(_mm512_add_epi32(f1, vecGapExtend), _mm512_add_epi32(h1, vecGapOE));
			f2 = _mm512_max_epi32(_mm512_add_epi32(f2, vecGapExtend), _mm512_add_epi32(h2, vecGapOE));
			f3 = _mm512_max_epi32(_mm512_add_epi32(f3, vecGapExtend), _mm512_add_epi32(h3, vecGapOE));
#if SEQ_LENGTH_ALIGN == 8
			f4 = _mm512_max_epi32(_mm512_add_epi32(f4, vecGapExtend), _mm512_add_epi32(h4, vecGapOE));
			f5 = _mm512_max_epi32(_mm512_add_epi32(f5, vecGapExtend), _mm512_add_epi32(h5, vecGapOE));
			f6 = _mm512_max_epi32(_mm512_add_epi32(f6, vecGapExtend), _mm512_add_epi32(h6, vecGapOE));
			f7 = _mm512_max_epi32(_mm512_add_epi32(f7, vecGapExtend), _mm512_add_epi32(h7, vecGapOE));
#endif

			/*partially comput H*/
			h0 = _mm512_max_epi32(vecZero, _mm512_add_epi32(d0, vecS0));
			h1 = _mm512_max_epi32(vecZero, _mm512_add_epi32(d1, vecS1));
			h2 = _mm512_max_epi32(vecZero, _mm512_add_epi32(d2, vecS2));
			h3 = _mm512_max_epi32(vecZero, _mm512_add_epi32(d3, vecS3));
#if SEQ_LENGTH_ALIGN == 8
			h4 = _mm512_max_epi32(vecZero, _mm512_add_epi32(d4, vecS4));
			h5 = _mm512_max_epi32(vecZero, _mm512_add_epi32(d5, vecS5));
			h6 = _mm512_max_epi32(vecZero, _mm512_add_epi32(d6, vecS6));
			h7 = _mm512_max_epi32(vecZero, _mm512_add_epi32(d7, vecS7));
#endif
			h0 = _mm512_max_epi32(h0, f0);
            h1 = _mm512_max_epi32(h1, f1);
            h2 = _mm512_max_epi32(h2, f2);
            h3 = _mm512_max_epi32(h3, f3);
#if SEQ_LENGTH_ALIGN == 8
			h4 = _mm512_max_epi32(h4, f4);
            h5 = _mm512_max_epi32(h5, f5);
            h6 = _mm512_max_epi32(h6, f6);
            h7 = _mm512_max_epi32(h7, f7);
#endif

			/*cell (0, col)*/
			/*compute the new E value*/
			vecE = _mm512_max_epi32(_mm512_add_epi32(vecE, vecGapExtend), _mm512_add_epi32(vecH, vecGapOE));
			h0 = _mm512_max_epi32(h0, vecE);
			vecMax = _mm512_max_epi32(vecMax, h0);
			d0 = vecH;

            /*cell (1, col)*/
            /*compute the new E value*/
            vecE = _mm512_max_epi32(_mm512_add_epi32(vecE, vecGapExtend), _mm512_add_epi32(h0, vecGapOE));
           	h1 = _mm512_max_epi32(h1, vecE);
			vecMax = _mm512_max_epi32(vecMax, h1);
			d1 = h0;

            /*cell (2, col)*/
            /*compute the new E value*/
            vecE = _mm512_max_epi32(_mm512_add_epi32(vecE, vecGapExtend), _mm512_add_epi32(h1, vecGapOE));
           	h2 = _mm512_max_epi32(h2, vecE);
			vecMax = _mm512_max_epi32(vecMax, h2);
			d2 = h1;

            /*cell (3, col)*/
            /*compute the new E value*/
            vecE = _mm512_max_epi32(_mm512_add_epi32(vecE, vecGapExtend), _mm512_add_epi32(h2, vecGapOE));
            h3 = _mm512_max_epi32(h3, vecE);
			vecMax = _mm512_max_epi32(vecMax, h3);
			d3 = h2;

#if SEQ_LENGTH_ALIGN == 8
			/*cell (4, col)*/
			/*compute the new E value*/
			vecE = _mm512_max_epi32(_mm512_add_epi32(vecE, vecGapExtend), _mm512_add_epi32(h3, vecGapOE));
			h4 = _mm512_max_epi32(h4, vecE);
			vecMax = _mm512_max_epi32(vecMax, h4);
			d4 = h3;

            /*cell (5, col)*/
            /*compute the new E value*/
            vecE = _mm512_max_epi32(_mm512_add_epi32(vecE, vecGapExtend), _mm512_add_epi32(h4, vecGapOE));
            h5 = _mm512_max_epi32(h5, vecE);
			vecMax = _mm512_max_epi32(vecMax, h5);
			d5 = h4;

            /*cell (6, col)*/
            /*compute the new E value*/
            vecE = _mm512_max_epi32(_mm512_add_epi32(vecE, vecGapExtend), _mm512_add_epi32(h5, vecGapOE));
            h6 = _mm512_max_epi32(h6, vecE);
			vecMax = _mm512_max_epi32(vecMax, h6);
			d6 = h5;

            /*cell (7, col)*/
            /*compute the new E value*/
            vecE = _mm512_max_epi32(_mm512_add_epi32(vecE, vecGapExtend), _mm512_add_epi32(h6, vecGapOE));
            h7 = _mm512_max_epi32(h7, vecE);
			vecMax = _mm512_max_epi32(vecMax, h7);
			d7 = h6;


			/*save the old values*/
			_mm512_store_epi32(vecHE, h7);
#else
			_mm512_store_epi32(vecHE, h3);
#endif
			_mm512_store_epi32(vecHE + 1, vecE);
			vecHE += 2;
		}
	}

	/*save the alignment score*/
	_mm512_store_epi32(vecAlnScores, vecMax);
#endif
}

__attribute__((target(mic))) void AlignCoreInter::swKernelQueryProfile(const int32_t queryLength, const __m128i* __restrict__ chunk, 
		const __m128i* __restrict__ qprofile, const int32_t chunkLength,
		__m512i* __restrict__ vecHEdata,__m512i* __restrict__ vecAlnScores,
		const __m512i vecGapOE, const __m512i vecGapExtend, const __m512i vecZero, const __m512i vecI16)
		{
			register __m512i vecQ0, vecQ1, vecQ2, vecQ3, vecQ4, vecQ5, vecQ6, vecQ7;
			register __m512i vecS0, vecS1, vecS2, vecS3, vecS4, vecS5, vecS6, vecS7;
			register __m512i vecH, vecE, vecMax;
			register __m512i h0, f0, h1, f1, h2, f2, h3, f3;
			register __m512i d0, d1, d2, d3;
			register __mmask16 vecM0, vecM1, vecM2, vecM3, vecM4, vecM5, vecM6, vecM7;
			__m512i* __restrict__ vecHE;
			const __m128i* __restrict__ qprfData;

#if SEQ_LENGTH_ALIGN == 8
			register __m512i h4, f4, h5, f5, h6, f6, h7, f7;
			register __m512i d4, d5, d6, d7;
#endif

#ifdef __MIC__

	/*clear the memory*/
	memset(vecHEdata, 0, queryLength * sizeof(__m512i) * 2);

	/*core loop*/
	vecMax = vecZero;
	for (int32_t row = 0; row < chunkLength; row += SEQ_LENGTH_ALIGN) { /*target on the row*/
		/*initialize*/
		f0 = f1 = f2 = f3 = vecZero;
		h0 = h1 = h2 = h3 = vecZero;
		d0 = d1 = d2 = d3 = vecZero;
#if SEQ_LENGTH_ALIGN == 8
		f4 = f5 = f6 = f7 = vecZero;
		h4 = h5 = h6 = h7 = vecZero;
		d4 = d5 = d6 = d7 = vecZero;
#endif

		/*get the amino acid vector*/
		vecQ0 = _mm512_extload_epi32(chunk, _MM_UPCONV_EPI32_UINT8, _MM_BROADCAST32_NONE, 0);
		vecQ1 = _mm512_extload_epi32(chunk + 1, _MM_UPCONV_EPI32_UINT8, _MM_BROADCAST32_NONE, 0);
		vecQ2 = _mm512_extload_epi32(chunk + 2, _MM_UPCONV_EPI32_UINT8, _MM_BROADCAST32_NONE, 0);
		vecQ3 = _mm512_extload_epi32(chunk + 3, _MM_UPCONV_EPI32_UINT8, _MM_BROADCAST32_NONE, 0);
#if SEQ_LENGTH_ALIGN == 8
		vecQ4 = _mm512_extload_epi32(chunk + 4, _MM_UPCONV_EPI32_UINT8, _MM_BROADCAST32_NONE, 0);
		vecQ5 = _mm512_extload_epi32(chunk + 5, _MM_UPCONV_EPI32_UINT8, _MM_BROADCAST32_NONE, 0);
		vecQ6 = _mm512_extload_epi32(chunk + 6, _MM_UPCONV_EPI32_UINT8, _MM_BROADCAST32_NONE, 0);
		vecQ7 = _mm512_extload_epi32(chunk + 7, _MM_UPCONV_EPI32_UINT8, _MM_BROADCAST32_NONE, 0);
#endif
		chunk += 8;

		vecM0 = _mm512_cmpge_epi32_mask(vecQ0, vecI16);
		vecM1 = _mm512_cmpge_epi32_mask(vecQ1, vecI16);
		vecM2 = _mm512_cmpge_epi32_mask(vecQ2, vecI16);
		vecM3 = _mm512_cmpge_epi32_mask(vecQ3, vecI16);
#if SEQ_LENGTH_ALIGN == 8
		vecM4 = _mm512_cmpge_epi32_mask(vecQ4, vecI16);
		vecM5 = _mm512_cmpge_epi32_mask(vecQ5, vecI16);
		vecM6 = _mm512_cmpge_epi32_mask(vecQ6, vecI16);
		vecM7 = _mm512_cmpge_epi32_mask(vecQ7, vecI16);
#endif

		/*adjust the indices*/
		vecQ0 = _mm512_mask_sub_epi32(vecQ0, vecM0, vecQ0, vecI16);
		vecQ1 = _mm512_mask_sub_epi32(vecQ1, vecM1, vecQ1, vecI16);
		vecQ2 = _mm512_mask_sub_epi32(vecQ2, vecM2, vecQ2, vecI16);
		vecQ3 = _mm512_mask_sub_epi32(vecQ3, vecM3, vecQ3, vecI16);
#if SEQ_LENGTH_ALIGN == 8
		vecQ4 = _mm512_mask_sub_epi32(vecQ4, vecM4, vecQ4, vecI16);
		vecQ5 = _mm512_mask_sub_epi32(vecQ5, vecM5, vecQ5, vecI16);
		vecQ6 = _mm512_mask_sub_epi32(vecQ6, vecM6, vecQ6, vecI16);
		vecQ7 = _mm512_mask_sub_epi32(vecQ7, vecM7, vecQ7, vecI16);
#endif
		/*the inner core loop*/
		vecHE = vecHEdata;
		qprfData = qprofile;

		for (int32_t col = 0; col < queryLength; ++col) { /*query on the column*/
			/*get the substitution scores*/
			vecH = _mm512_extload_epi32(qprfData++, _MM_UPCONV_EPI32_SINT8, _MM_BROADCAST32_NONE, 0);
			vecE = _mm512_extload_epi32(qprfData++, _MM_UPCONV_EPI32_SINT8, _MM_BROADCAST32_NONE, 0);

			vecS0 = _mm512_permutevar_epi32(vecQ0, vecH);
			vecS1 = _mm512_permutevar_epi32(vecQ1, vecH);
			vecS2 = _mm512_permutevar_epi32(vecQ2, vecH);
			vecS3 = _mm512_permutevar_epi32(vecQ3, vecH);
#if SEQ_LENGTH_ALIGN == 8
			vecS4 = _mm512_permutevar_epi32(vecQ4, vecH);
			vecS5 = _mm512_permutevar_epi32(vecQ5, vecH);
			vecS6 = _mm512_permutevar_epi32(vecQ6, vecH);
			vecS7 = _mm512_permutevar_epi32(vecQ7, vecH);
#endif

			vecS0 = _mm512_mask_permutevar_epi32(vecS0, vecM0, vecQ0, vecE);
			vecS1 = _mm512_mask_permutevar_epi32(vecS1, vecM1, vecQ1, vecE);
			vecS2 = _mm512_mask_permutevar_epi32(vecS2, vecM2, vecQ2, vecE);
			vecS3 = _mm512_mask_permutevar_epi32(vecS3, vecM3, vecQ3, vecE);
#if SEQ_LENGTH_ALIGN == 8
			vecS4 = _mm512_mask_permutevar_epi32(vecS4, vecM4, vecQ4, vecE);
			vecS5 = _mm512_mask_permutevar_epi32(vecS5, vecM5, vecQ5, vecE);
			vecS6 = _mm512_mask_permutevar_epi32(vecS6, vecM6, vecQ6, vecE);
			vecS7 = _mm512_mask_permutevar_epi32(vecS7, vecM7, vecQ7, vecE);
#endif
			/*get the H and E values*/
			vecH = _mm512_load_epi32(vecHE);	/*must be 64-byte-aligned*/
			vecE = _mm512_load_epi32(vecHE + 1);	/*must be 64-byte-aligned*/

			/*compute the new F value*/
			f0 = _mm512_max_epi32(_mm512_add_epi32(f0, vecGapExtend), _mm512_add_epi32(h0, vecGapOE));
			f1 = _mm512_max_epi32(_mm512_add_epi32(f1, vecGapExtend), _mm512_add_epi32(h1, vecGapOE));
			f2 = _mm512_max_epi32(_mm512_add_epi32(f2, vecGapExtend), _mm512_add_epi32(h2, vecGapOE));
			f3 = _mm512_max_epi32(_mm512_add_epi32(f3, vecGapExtend), _mm512_add_epi32(h3, vecGapOE));
#if SEQ_LENGTH_ALIGN == 8
			f4 = _mm512_max_epi32(_mm512_add_epi32(f4, vecGapExtend), _mm512_add_epi32(h4, vecGapOE));
			f5 = _mm512_max_epi32(_mm512_add_epi32(f5, vecGapExtend), _mm512_add_epi32(h5, vecGapOE));
			f6 = _mm512_max_epi32(_mm512_add_epi32(f6, vecGapExtend), _mm512_add_epi32(h6, vecGapOE));
			f7 = _mm512_max_epi32(_mm512_add_epi32(f7, vecGapExtend), _mm512_add_epi32(h7, vecGapOE));
#endif

			/*partially comput H*/
			h0 = _mm512_max_epi32(vecZero, _mm512_add_epi32(d0, vecS0));
			h1 = _mm512_max_epi32(vecZero, _mm512_add_epi32(d1, vecS1));
			h2 = _mm512_max_epi32(vecZero, _mm512_add_epi32(d2, vecS2));
			h3 = _mm512_max_epi32(vecZero, _mm512_add_epi32(d3, vecS3));
#if SEQ_LENGTH_ALIGN == 8
			h4 = _mm512_max_epi32(vecZero, _mm512_add_epi32(d4, vecS4));
			h5 = _mm512_max_epi32(vecZero, _mm512_add_epi32(d5, vecS5));
			h6 = _mm512_max_epi32(vecZero, _mm512_add_epi32(d6, vecS6));
			h7 = _mm512_max_epi32(vecZero, _mm512_add_epi32(d7, vecS7));
#endif
			h0 = _mm512_max_epi32(h0, f0);
            h1 = _mm512_max_epi32(h1, f1);
            h2 = _mm512_max_epi32(h2, f2);
            h3 = _mm512_max_epi32(h3, f3);
#if SEQ_LENGTH_ALIGN == 8
			h4 = _mm512_max_epi32(h4, f4);
            h5 = _mm512_max_epi32(h5, f5);
            h6 = _mm512_max_epi32(h6, f6);
            h7 = _mm512_max_epi32(h7, f7);
#endif

			/*cell (0, col)*/
			/*compute the new E value*/
			vecE = _mm512_max_epi32(_mm512_add_epi32(vecE, vecGapExtend), _mm512_add_epi32(vecH, vecGapOE));
			h0 = _mm512_max_epi32(h0, vecE);
			vecMax = _mm512_max_epi32(vecMax, h0);
			d0 = vecH;

            /*cell (1, col)*/
            /*compute the new E value*/
            vecE = _mm512_max_epi32(_mm512_add_epi32(vecE, vecGapExtend), _mm512_add_epi32(h0, vecGapOE));
           	h1 = _mm512_max_epi32(h1, vecE);
			vecMax = _mm512_max_epi32(vecMax, h1);
			d1 = h0;

            /*cell (2, col)*/
            /*compute the new E value*/
            vecE = _mm512_max_epi32(_mm512_add_epi32(vecE, vecGapExtend), _mm512_add_epi32(h1, vecGapOE));
           	h2 = _mm512_max_epi32(h2, vecE);
			vecMax = _mm512_max_epi32(vecMax, h2);
			d2 = h1;

            /*cell (3, col)*/
            /*compute the new E value*/
            vecE = _mm512_max_epi32(_mm512_add_epi32(vecE, vecGapExtend), _mm512_add_epi32(h2, vecGapOE));
            h3 = _mm512_max_epi32(h3, vecE);
			vecMax = _mm512_max_epi32(vecMax, h3);
			d3 = h2;

#if SEQ_LENGTH_ALIGN == 8
			/*cell (4, col)*/
			/*compute the new E value*/
			vecE = _mm512_max_epi32(_mm512_add_epi32(vecE, vecGapExtend), _mm512_add_epi32(h3, vecGapOE));
			h4 = _mm512_max_epi32(h4, vecE);
			vecMax = _mm512_max_epi32(vecMax, h4);
			d4 = h3;

            /*cell (5, col)*/
            /*compute the new E value*/
            vecE = _mm512_max_epi32(_mm512_add_epi32(vecE, vecGapExtend), _mm512_add_epi32(h4, vecGapOE));
            h5 = _mm512_max_epi32(h5, vecE);
			vecMax = _mm512_max_epi32(vecMax, h5);
			d5 = h4;

            /*cell (6, col)*/
            /*compute the new E value*/
            vecE = _mm512_max_epi32(_mm512_add_epi32(vecE, vecGapExtend), _mm512_add_epi32(h5, vecGapOE));
            h6 = _mm512_max_epi32(h6, vecE);
			vecMax = _mm512_max_epi32(vecMax, h6);
			d6 = h5;

            /*cell (7, col)*/
            /*compute the new E value*/
            vecE = _mm512_max_epi32(_mm512_add_epi32(vecE, vecGapExtend), _mm512_add_epi32(h6, vecGapOE));
            h7 = _mm512_max_epi32(h7, vecE);
			vecMax = _mm512_max_epi32(vecMax, h7);
			d7 = h6;


			/*save the old values*/
			_mm512_store_epi32(vecHE, h7);
#else
			_mm512_store_epi32(vecHE, h3);
#endif
			_mm512_store_epi32(vecHE + 1, vecE);
			vecHE += 2;
		}
	}

	/*save the alignment score*/
	_mm512_store_epi32(vecAlnScores, vecMax);
#endif
}

